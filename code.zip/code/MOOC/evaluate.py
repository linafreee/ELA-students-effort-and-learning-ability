import time
from sklearn.metrics import precision_score, recall_score, f1_score
import pandas as pd
# import logisticRegression
import numpy as np

class evaluate():
    def __init__(self):
        self.path = "F:/Pycharm/paper/Learning Ability/data/MOOC/metric/"

    def metric(self, grade_category, grade_pred_category,type):
        self.type = type
        self.grade_category = grade_category
        self.grade_prd_category = grade_pred_category

        self.macro_precision = precision_score(self.grade_category, self.grade_prd_category, average='macro')
        self.micro_precision = precision_score(self.grade_category, self.grade_prd_category,average='micro')
        self.macro_recall = recall_score(self.grade_category, self.grade_prd_category, average='macro')
        self.micro_recall = recall_score(self.grade_category, self.grade_prd_category, average='micro')
        self.macro_f1 = f1_score(self.grade_category, self.grade_prd_category, average='macro')
        self.micro_f1 = f1_score(self.grade_category, self.grade_prd_category, average='micro')

        if type == 'evaluate':
            self.evaluate_list = []
            self.evaluate_list.append(self.macro_f1)
            self.evaluate_list.append(self.micro_f1)
            return self.evaluate_list

        if type == 'test':
            self.metric_list = []
            self.metric_list.append(self.macro_precision)
            self.metric_list.append(self.micro_precision)
            self.metric_list.append(self.macro_recall)
            self.metric_list.append(self.micro_recall)
            self.metric_list.append(self.macro_f1)
            self.metric_list.append(self.micro_f1)
            return self.metric_list


if __name__ == '__main__':
    pass