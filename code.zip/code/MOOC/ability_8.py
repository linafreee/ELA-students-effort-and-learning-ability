import numpy as np
import random
import math

class train_ability():
    def __init__(self, effort_data,train_data,iterate,lamda_a,lamda_s,lamda_w,eta_a,eta_w):
        self.train_data = train_data
        # print("init...")  # X*W=y_pred (m*2)*(2,1)=(m*1)
        # weight
        self.W = np.random.rand(2, 1)  # 学习;分别为努力和学习能力的权重
        self.beta = random.random()  # 学习-输出
        # effort
        self.E = effort_data
        self.E = self.E.reshape(len(self.E), 1)  # 定值，与A组合成矩阵
        # ability
        self.A = np.random.rand(len(self.E), 1)  # 学习
        # X=(E,A) m*2
        self.X = np.hstack((self.E, self.A))
        # grade y
        self.y = self.train_data.ix[:, 6:7]
        self.y = self.y.values
        self.y = self.y.reshape(len(self.y), 1)
        self.A_pred = self.get_ability_pred(self.beta, self.A)
        self.A_T0, self.A_T1, self.A_T2, self.A_T3, self.A_T4, self.A_T5, self.A_T6,self.A_T7 = self.get_ability_split(self.A)
        self.A_pred_T0, self.A_pred_T1, self.A_pred_T2, self.A_pred_T3, self.A_pred_T4, self.A_pred_T5, self.A_pred_T6, \
        self.A_pred_T7 = self.get_ability_split(self.A_pred)
        # The Learning Rate eta
        self.eta_a = eta_a  # 步长
        self.eta_w = eta_w
        self.iterate_tune = iterate
        self.iterate = 0
        self.lamda_w = lamda_w  # 定值
        self.lamda_a = lamda_a  # 超参数,需要分析
        self.lamda_s = lamda_s  # 超参数,需要分析



    def gradient_descent(self):
        # print("gradient_descent...")
        self.gradient_A = self.gradient_function_E_step(self.W, self.X, self.y,self.A,self.A_pred,self.A_T0,self.A_T1, self.A_T2, self.A_T3, self.A_T4, self.A_T5, self.A_T6,self.A_T7)  # m*1
        while self.iterate < self.iterate_tune:
            self.A = self.A - self.eta_a * self.gradient_A
            self.X = np.hstack((self.E, self.A))
            self.A_pred = self.get_ability_pred(self.beta, self.A)
            self.A_T0, self.A_T1, self.A_T2, self.A_T3, self.A_T4, self.A_T5, self.A_T6,self.A_T7 = self.get_ability_split(self.A)
            self.A_pred_T0, self.A_pred_T1, self.A_pred_T2, self.A_pred_T3, self.A_pred_T4, self.A_pred_T5, self.A_pred_T6,self.A_pred_T7= self.get_ability_split(self.A_pred)
            self.gradient_W, self.gradient_beta = self.gradient_function_M_step(self.W, self.X, self.y,self.A_T1,self.A_T2, self.A_T3, self.A_T4, self.A_T5, self.A_T6,self.A_T7, self.A_pred_T1, self.A_pred_T2, self.A_pred_T3, self.A_pred_T4, self.A_pred_T5, self.A_pred_T6,self.A_pred_T7)  # m*1 # 3*1
            # M步
            self.W = self.W - self.eta_w * self.gradient_W
            self.beta = self.beta - self.eta_w * self.gradient_beta
            self.A_pred = self.get_ability_pred(self.beta, self.A)
            self.A_T0, self.A_T1, self.A_T2, self.A_T3, self.A_T4, self.A_T5, self.A_T6,self.A_T7 = self.get_ability_split(self.A)
            self.gradient_A = self.gradient_function_E_step(self.W, self.X, self.y, self.A, self.A_pred, self.A_T0, self.A_T1, self.A_T2, self.A_T3, self.A_T4, self.A_T5, self.A_T6,self.A_T7)
            self.iterate += 1

        self.error = self.loss_function(self.W, self.A, self.X, self.y,self.A_pred,self.A_T0,self.A_T1,self.A_T2,self.A_T3,self.A_T4,self.A_T5,self.A_T6,self.A_T7, self.beta)
        self.A_T0, self.A_T1, self.A_T2, self.A_T3, self.A_T4, self.A_T5, self.A_T6,self.A_T7 = self.get_ability_split(self.A)
        self.A_T8 = np.random.rand(len(self.A_T7), 1)
        for i in range(0, len(self.A_T7)):
            self.A_T8[i][0] = 1 / (1 + np.exp(self.beta - self.A_T7[int(i)][0]))

        return self.error, self.A,self.A_T8,self.beta

    def get_ability_pred(self, beta, A):
        self.beta = beta
        self.A_pred = A
        for i in range(1, len(self.A_pred)):
            if i % 8 == 1:
                self.A_pred[i][0] = 1 / (1 + np.exp(self.beta - self.A_pred[i-1][0]))
                self.A_pred[i+1][0] = 1 / (1 + np.exp(self.beta - self.A_pred[i][0]))
                self.A_pred[i+2][0] = 1 / (1 + np.exp(self.beta - self.A_pred[i+1][0]))
                self.A_pred[i+3][0] = 1 / (1 + np.exp(self.beta - self.A_pred[i+2][0]))
                self.A_pred[i+4][0] = 1 / (1 + np.exp(self.beta - self.A_pred[i+3][0]))
                self.A_pred[i+5][0] = 1 / (1 + np.exp(self.beta - self.A_pred[i+4][0]))
                self.A_pred[i + 6][0] = 1 / (1 + np.exp(self.beta - self.A_pred[i + 5][0]))
        # print(self.A_pred)
        return self.A_pred

    # 按时间(课程)拆分学习能力
    def get_ability_split(self, A):
        self.A = A
        self.T = 8
        self.A_T0 = np.random.rand(int(len(self.A)/self.T), 1)
        self.A_T1 = np.random.rand(int(len(self.A)/self.T), 1)
        self.A_T2 = np.random.rand(int(len(self.A) / self.T), 1)
        self.A_T3 = np.random.rand(int(len(self.A) / self.T), 1)
        self.A_T4 = np.random.rand(int(len(self.A) / self.T), 1)
        self.A_T5 = np.random.rand(int(len(self.A) / self.T), 1)
        self.A_T6 = np.random.rand(int(len(self.A) / self.T), 1)
        self.A_T7 = np.random.rand(int(len(self.A) / self.T), 1)
        for i in range(len(self.A)):
            if i % self.T == 0:
                self.A_T0[int(i/self.T)][0] = self.A[i][0]
            if i % self.T == 1:
                self.A_T1[int(i/self.T)][0] = self.A[i][0]
            if i % self.T == 2:
                self.A_T2[int(i/self.T)][0] = self.A[i][0]
            if i % self.T == 3:
                self.A_T3[int(i/self.T)][0] = self.A[i][0]
            if i % self.T == 4:
                self.A_T4[int(i/self.T)][0] = self.A[i][0]
            if i % self.T == 5:
                self.A_T5[int(i/self.T)][0] = self.A[i][0]
            if i % self.T == 6:
                self.A_T6[int(i/self.T)][0] = self.A[i][0]
            if i % self.T == 7:
                self.A_T7[int(i/self.T)][0] = self.A[i][0]
        return self.A_T0, self.A_T1,self.A_T2,self.A_T3,self.A_T4,self.A_T5,self.A_T6,self.A_T7

    def gradient_function_E_step(self, W, X, y,A, A_pred, A_T0, A_T1,A_T2,A_T3,A_T4,A_T5,A_T6,A_T7):  # 固定W,更新A
        '''Gradient of the function J definition.'''
        self.W = W
        self.X = X
        self.y = y
        self.A = A
        self.A_pred = A_pred
        self.A_T0 = A_T0
        self.A_T1 = A_T1
        self.A_T2 = A_T2
        self.A_T3 = A_T3
        self.A_T4 = A_T4
        self.A_T5 = A_T5
        self.A_T6 = A_T6
        self.A_T7 = A_T7
        self.A_T1_diff = self.A_T1 - self.A_T0
        self.A_T2_diff = self.A_T2 - self.A_T1
        self.A_T3_diff = self.A_T3 - self.A_T2
        self.A_T4_diff = self.A_T4 - self.A_T3
        self.A_T5_diff = self.A_T5 - self.A_T4
        self.A_T6_diff = self.A_T6 - self.A_T5
        self.A_T7_diff = self.A_T7 - self.A_T6
        self.A_T = np.random.rand(len(self.A), 1)
        self.T = 8
        for i in range(0,len(self.A),self.T):
            self.A_T[i][0] = -self.A_T1_diff[int(i/self.T)][0]
            self.A_T[i + 1][0] = self.A_T1_diff[int(i/self.T)][0] - self.A_T2_diff[int(i/self.T)][0]
            self.A_T[i + 2][0] = self.A_T2_diff[int(i / self.T)][0] - self.A_T3_diff[int(i / self.T)][0]
            self.A_T[i + 3][0] = self.A_T3_diff[int(i / self.T)][0] - self.A_T4_diff[int(i / self.T)][0]
            self.A_T[i + 4][0] = self.A_T4_diff[int(i / self.T)][0] - self.A_T5_diff[int(i / self.T)][0]
            self.A_T[i + 5][0] = self.A_T5_diff[int(i / self.T)][0] - self.A_T6_diff[int(i / self.T)][0]
            self.A_T[i + 6][0] = self.A_T6_diff[int(i / self.T)][0] - self.A_T7_diff[int(i / self.T)][0]
            self.A_T[i + 7][0] = self.A_T7_diff[int(i / self.T)][0]
        self.diff = np.dot(self.X, self.W) - self.y  # m*1
        self.gradient_A = np.dot(self.diff, self.W[1].reshape(1, 1)) + (self.A - self.A_pred) + self.lamda_s * self.A_T
        return self.gradient_A

    def gradient_function_M_step(self, W, X, y,A_T1,A_T2,A_T3,A_T4,A_T5,A_T6,A_T7,A_pred_T1,A_pred_T2,A_pred_T3,A_pred_T4,A_pred_T5,A_pred_T6,A_pred_T7):  # 固定X,更新W
        '''Gradient of the function J definition.'''
        self.W = W
        self.X = X
        self.y = y
        self.A_T1 = A_T1
        self.A_T2 = A_T2
        self.A_T3 = A_T3
        self.A_T4 = A_T4
        self.A_T5 = A_T5
        self.A_T6 = A_T6
        self.A_T7 = A_T7
        self.A_pred_T1 = A_pred_T1
        self.A_pred_T2 = A_pred_T2
        self.A_pred_T3 = A_pred_T3
        self.A_pred_T4 = A_pred_T4
        self.A_pred_T5 = A_pred_T5
        self.A_pred_T6 = A_pred_T6
        self.A_pred_T7 = A_pred_T7
        self.diff = np.dot(self.X,self.W) - self.y  # m*1
        self.W = np.absolute(self.W)
        self.gradient_W = np.dot(np.transpose(self.X), self.diff) / len(self.E) + self.lamda_w * self.W  # (2*m)*(m*1)
        self.gradient_beta_sum = 0
        for i in range(len(self.A_pred_T0)):
            self.gradient_beta_0 = self.A_pred_T0[i][0] * (1 - self.A_pred_T0[i][0]) * (-1)
            self.gradient_beta_1 = self.A_pred_T1[i][0] * (1 - self.A_pred_T1[i][0]) * (self.gradient_beta_0 - 1)
            self.gradient_beta_2 = self.A_pred_T2[i][0] * (1 - self.A_pred_T2[i][0]) * (self.gradient_beta_1 - 1)
            self.gradient_beta_3 = self.A_pred_T3[i][0] * (1 - self.A_pred_T3[i][0]) * (self.gradient_beta_2 - 1)
            self.gradient_beta_4 = self.A_pred_T4[i][0] * (1 - self.A_pred_T4[i][0]) * (self.gradient_beta_3 - 1)
            self.gradient_beta_5 = self.A_pred_T5[i][0] * (1 - self.A_pred_T5[i][0]) * (self.gradient_beta_4 - 1)
            self.gradient_beta_6 = self.A_pred_T6[i][0] * (1 - self.A_pred_T6[i][0]) * (self.gradient_beta_5 - 1)
            self.gradient_beta_7 = self.A_pred_T7[i][0] * (1 - self.A_pred_T7[i][0]) * (self.gradient_beta_6 - 1)
            self.sum = (self.A_pred_T7[i][0] - self.A_T7[i][0]) * self.gradient_beta_7 + (
                        self.A_pred_T6[i][0] - self.A_T6[i][0]) * self.gradient_beta_6 + \
                       (self.A_pred_T5[i][0] - self.A_T5[i][0]) * self.gradient_beta_5 + (
                        self.A_pred_T4[i][0] - self.A_T4[i][0]) * self.gradient_beta_4 + \
                       (self.A_pred_T3[i][0] - self.A_T3[i][0]) * self.gradient_beta_3 + (
                        self.A_pred_T2[i][0] - self.A_T2[i][0]) * self.gradient_beta_2 + \
                       (self.A_pred_T1[i][0] - self.A_T1[i][0]) * self.gradient_beta_1
            self.gradient_beta_sum += self.sum
        self.gradient_beta = self.gradient_beta_sum / (len(self.E) - len(self.A_T1)) + self.lamda_a * self.beta
        return self.gradient_W, self.gradient_beta

    def loss_function(self, W, A, X, y,A_pred,A_T0,A_T1,A_T2,A_T3,A_T4,A_T5,A_T6,A_T7,beta):
        '''Error function J definition.'''
        self.W = W
        self.beta = beta
        self.X = X
        self.y = y
        self.A = A
        self.A_pred = A_pred
        self.A_T0 = A_T0
        self.A_T1 = A_T1
        self.A_T1 = A_T2
        self.A_T1 = A_T3
        self.A_T1 = A_T4
        self.A_T1 = A_T5
        self.A_T1 = A_T6
        self.A_T7 = A_T7
        self.diff = np.dot(self.X,self.W) - self.y
        self.sum_smooth = np.dot(np.transpose(self.A_T1-self.A_T0), self.A_T1-self.A_T0)
        self.sum_smooth += np.dot(np.transpose(self.A_T2-self.A_T1), self.A_T2-self.A_T1)
        self.sum_smooth += np.dot(np.transpose(self.A_T3 - self.A_T2), self.A_T3 - self.A_T2)
        self.sum_smooth += np.dot(np.transpose(self.A_T4 - self.A_T3), self.A_T4 - self.A_T3)
        self.sum_smooth += np.dot(np.transpose(self.A_T5 - self.A_T4), self.A_T5 - self.A_T4)
        self.sum_smooth += np.dot(np.transpose(self.A_T6 - self.A_T5), self.A_T6 - self.A_T5)
        self.sum_smooth += np.dot(np.transpose(self.A_T7 - self.A_T6), self.A_T7 - self.A_T6)
        self.loss = 1. / (2 * len(self.E)) * np.dot(np.transpose(self.diff), self.diff) + \
                    1 / (2 * len(self.E)) * np.dot(np.transpose(self.A - self.A_pred), self.A - self.A_pred) + \
                    self.lamda_s / (2 * (len(self.E) - len(self.A_T0))) * self.sum_smooth + \
                    self.lamda_w / 2 * np.dot(np.transpose(self.W), self.W) + self.lamda_a / 2 * np.square(self.beta)
        return self.loss


if __name__ == '__main__':
    pass
