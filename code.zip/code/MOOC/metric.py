import time
import compared_method


class metric():
    def __init__(self):
        self.path = "F:/Pycharm/paper/data/MOOC/model/"

    def compare(self):
        print('com_exper')
        self.file_tv = self.path + 'comp_train_validate_'
        self.file_t = self.path + 'comp_test_'
        self.com = compared_method.method(self.file_tv, self.file_t, 4)
        self.com.LR()
        # self.com.SVM()
        # self.com.NN()



if __name__ == '__main__':
    start = time.clock()
    m = metric()
    m.compare()
    end = time.clock()
    print("time_run:", end - start)