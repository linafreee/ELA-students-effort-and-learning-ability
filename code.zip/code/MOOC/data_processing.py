import json
import csv
import time
import pandas as pd
import numpy as np

class raw_data_processing():
    def __init__(self):
        self.path = "F:/Pycharm/paper/data/Learning Ability/MOOC/"
        self.user_file = open(self.path + 'MOOC_data_middle/userId.json', 'r', encoding='utf-8')
        self.userId = json.load(self.user_file)
        self.userId = [str(int(i)) for i in self.userId]
        self.course_list = ['TsinghuaX-30240184_1X-_', 'TsinghuaX-20220332_1X-_', 'TsinghuaX-00690242_1X-_',
                            'TsinghuaX-80512073X-_', 'TsinghuaX-80000901_1X-_', 'PekingX-01718330X-_',
                            'TsinghuaX-20220332_2X-_', 'TsinghuaX-80000901_2X-_', 'TsinghuaX-80512073_2014_1X-_',
                            'TsinghuaX-00720091X-_', 'TsinghuaX-60240013X-_']


    def data_combine_grade(self):
        with open(self.path + 'MOOC_data_middle/grade_processed.csv', 'w+', newline='') as f:  # test
            self.fieldnames = ['course_id', 'userid_DI', 'grade']
            self.course_user_grade_data = csv.DictWriter(f, fieldnames=self.fieldnames)
            self.course_user_grade_data.writeheader()
            for self.course_id in self.course_list:
                with open(self.path + 'MOOC_data_middle/grades_csv/grades_' + self.course_id + '.csv', 'r') as f:
                    self.course_data = csv.DictReader(f)
                    for row in self.course_data:
                        if row['ID'] in self.userId:
                            if self.course_id == 'TsinghuaX-00720091X-_' or self.course_id == 'TsinghuaX-80512073_2014_1X-_' \
                                    or self.course_id == 'TsinghuaX-80512073X-_' or self.course_id == 'TsinghuaX-30240184_1X-_' \
                                    or self.course_id == 'TsinghuaX-60240013X-_' or self.course_id == 'TsinghuaX-80000901_1X-_'\
                                    or self.course_id == 'TsinghuaX-80000901_2X-_':
                                self.course_user_grade_data.writerow({'course_id': self.course_id, 'userid_DI': row['ID'],
                                                                      'grade': float(row['Final'])/100})
                            if self.course_id == 'PekingX-01718330X-_' or self.course_id == 'TsinghuaX-00690242_1X-_'\
                                    or self.course_id == 'TsinghuaX-20220332_1X-_' or self.course_id == 'TsinghuaX-20220332_2X-_':
                                self.course_user_grade_data.writerow({'course_id': self.course_id, 'userid_DI': row['ID'],
                                                                      'grade': row['Final']})


    def log_pre_processing(self):
        with open(self.path + 'MOOC_data_middle/pre_log_processed.csv', 'w+', newline='') as f:
            self.fieldnames = ['course_id', 'userid_DI', 'video', 'assignment']
            self.pre_log_processing_data = csv.DictWriter(f, fieldnames=self.fieldnames)
            self.pre_log_processing_data.writeheader()
            with open(self.path + 'MOOC_data_middle/log.csv', 'r') as f_1:
                self.log_data = csv.DictReader(f_1)
                for row in self.log_data:
                    if row['ID'] in self.userId and row['course_id'] in self.course_list:
                        print(row['ID'])
                        self.pre_log_processing_data.writerow({'course_id': row['course_id'], 'userid_DI': row['ID'],
                                                           'video': row['video'], 'assignment': row['assignment']})

    def forum_pre_processing(self):
        with open(self.path + 'MOOC_data_middle/pre_forum_processed.csv', 'w+', newline='') as f:
            self.fieldnames = ['course_id', 'userid_DI', 'length', 'vote_up']
            self.pre_forum_processing_data = csv.DictWriter(f, fieldnames=self.fieldnames)
            self.pre_forum_processing_data.writeheader()
            with open(self.path + 'MOOC_data_middle/forum.csv', 'r') as f_1:
                self.forum_data = csv.DictReader(f_1)
                for row in self.forum_data:
                    if row['ID'] in self.userId and row['course_id'] in self.course_list:
                        print(row['ID'])
                        self.pre_forum_processing_data.writerow({'course_id': row['course_id'], 'userid_DI': row['ID'],
                                                                 'length': row['length'], 'vote_up': row['vote_up']})


    def log_processing(self):
        with open(self.path + 'MOOC_data_middle/log_processed.csv', 'w+', newline='') as f:
            self.fieldnames = ['course_id', 'userid_DI', 'video', 'assignment']
            self.log_processing_data = csv.DictWriter(f, fieldnames=self.fieldnames)
            self.log_processing_data.writeheader()
            for self.log_user in self.userId:
                print(self.log_user)
                for self.log_course in self.course_list:
                    self.log_video = 0
                    self.log_assignment = 0
                    with open(self.path + 'MOOC_data_middle/pre_log_processed.csv', 'r') as f_1:
                        self.log_data = csv.DictReader(f_1)
                        for row in self.log_data:
                            if row['userid_DI'] == self.log_user and row['course_id'] == self.log_course:
                                self.log_video += float(row['video'])
                                self.log_assignment += float(row['assignment'])
                    if self.log_video != 0 or self.log_assignment != 0:
                        self.log_processing_data.writerow({'course_id': self.log_course, 'userid_DI': self.log_user,
                                                           'video': self.log_video, 'assignment': self.log_assignment})

    def forum_processing(self):
        with open(self.path + 'MOOC_data_middle/forum_processed.csv', 'w+', newline='') as f:
            self.fieldnames = ['course_id', 'userid_DI', 'length', 'vote_up']
            self.forum_processing_data = csv.DictWriter(f, fieldnames=self.fieldnames)
            self.forum_processing_data.writeheader()
            for self.forum_user in self.userId:
                for self.forum_course in self.course_list:
                    self.forum_length = 0
                    self.forum_vote_up = 0
                    with open(self.path + 'MOOC_data_middle/pre_forum_processed.csv', 'r') as f_1:
                        self.forum_data = csv.DictReader(f_1)
                        for row in self.forum_data:
                            if row['userid_DI'] == self.forum_user and row['course_id'] == self.forum_course:
                                self.forum_length += float(row['length'])
                                self.forum_vote_up += float(row['vote_up'])
                    if self.forum_length != 0 or self.forum_vote_up != 0:
                        self.forum_processing_data.writerow({'course_id': self.forum_course, 'userid_DI': self.forum_user,
                                                            'length': self.forum_length, 'vote_up': self.forum_vote_up})

    def combine_all(self):
        with open(self.path + 'MOOC_data/data_all.csv', 'w+', newline='') as f:  # test
            self.fieldnames = ['course_id', 'userid_DI', 'video', 'assignment', 'length', 'vote_up', 'grade', 'grade_category']
            self.final_data = csv.DictWriter(f, fieldnames=self.fieldnames)
            self.final_data.writeheader()
            for self.final_user in self.userId:
                for self.final_course in self.course_list:
                    self.final_video = 0
                    self.final_assignment = 0
                    self.final_length = 0
                    self.final_vote_up = 0
                    self.final_grade = 0
                    with open(self.path + 'MOOC_data_middle/log_processed.csv', 'r') as f_1:
                        self.log_final_data = csv.DictReader(f_1)
                        for row_1 in self.log_final_data:
                            if row_1['userid_DI'] == self.final_user and row_1['course_id'] == self.final_course:
                                self.final_video = row_1['video']
                                self.final_assignment = row_1['assignment']
                                break
                    with open(self.path + 'MOOC_data_middle/forum_processed.csv', 'r') as f_2:
                        self.forum_final_data = csv.DictReader(f_2)
                        for row_2 in self.forum_final_data:
                            if row_2['userid_DI'] == self.final_user and row_2['course_id'] == self.final_course:
                                self.final_length = row_2['length']
                                self.final_vote_up = row_2['vote_up']
                                break
                    with open(self.path + 'MOOC_data_middle/grade_processed.csv', 'r') as f_3:
                        self.grade_final_data = csv.DictReader(f_3)
                        for row_3 in self.grade_final_data:
                            if row_3['userid_DI'] == self.final_user and row_3['course_id'] == self.final_course:
                                self.final_grade = float(row_3['grade'])
                                break
                    if 0 <= self.final_grade < 0.2:
                        self.grade_category = 'E'
                    elif self.final_grade < 0.4:
                        self.grade_category = 'D'
                    elif self.final_grade < 0.6:
                        self.grade_category = 'C'
                    elif self.final_grade < 0.8:
                        self.grade_category = 'B'
                    else:
                        self.grade_category = 'A'
                    self.final_data.writerow({'course_id': self.final_course, 'userid_DI': self.final_user,
                                              'video': self.final_video, 'assignment': self.final_assignment,
                                              'length': self.final_length, 'vote_up': self.final_vote_up,
                                              'grade': self.final_grade, 'grade_category': self.grade_category})

    def zero_mean_normalization(self):
        self.raw_data = pd.read_csv(self.path + 'MOOC_data/data_all.csv')
        self.raw_data = pd.DataFrame(self.raw_data)
        self.raw_data['video'] = (self.raw_data['video'] - self.raw_data['video'].min()) / \
                                 (self.raw_data['video'].max() - self.raw_data['video'].min())
        self.raw_data['assignment'] = (self.raw_data['assignment'] - self.raw_data['assignment'].min()) / \
                                 (self.raw_data['assignment'].max() - self.raw_data['assignment'].min())
        self.raw_data['length'] = (self.raw_data['length'] - self.raw_data['length'].min()) / \
                                 (self.raw_data['length'].max() - self.raw_data['length'].min())
        self.raw_data['vote_up'] = (self.raw_data['vote_up'] - self.raw_data['vote_up'].min()) / \
                                 (self.raw_data['vote_up'].max() - self.raw_data['vote_up'].min())
        self.raw_data.to_csv(self.path + 'MOOC_data/normal_data_all.csv')

    def train_validate_test(self):
        # with open(self.path + 'MOOC_data/tune_T/10_train.csv', 'w+', newline='') as f:
        #     fieldnames = ['course_id', 'userid_DI', 'video', 'assignment', 'length', 'vote_up', 'grade', 'grade_category']
        #     self.data_train = csv.DictWriter(f, fieldnames=fieldnames)
        #     self.data_train.writeheader()
        #     with open(self.path + 'MOOC_data/normal_data_all.csv', 'r') as f_1:
        #         self.normal_data = csv.DictReader(f_1)
        #         for row in self.normal_data:
        #             if 0 <= self.course_list.index(row['course_id']) < 10:
        #                         self.data_train.writerow({'course_id': row['course_id'], 'userid_DI': row['userid_DI'],
        #                                                   'video': row['video'], 'assignment': row['assignment'],
        #                                                   'length': row['length'], 'vote_up': row['vote_up'],
        #                                                   'grade': row['grade'], 'grade_category': row['grade_category']})

        with open(self.path + 'MOOC_data/data_train_validate.csv', 'w+', newline='') as f_2:
            fieldnames = ['course_id', 'userid_DI', 'video', 'assignment', 'length', 'vote_up', 'grade', 'grade_category']
            self.data_test = csv.DictWriter(f_2, fieldnames=fieldnames)
            self.data_test.writeheader()
            with open(self.path + 'MOOC_data/normal_data_all.csv', 'r') as f_3:
                self.normal_data = csv.DictReader(f_3)
                for row in self.normal_data:
                    if 0 <= self.course_list.index(row['course_id']) < 10:
                                self.data_test.writerow({'course_id': row['course_id'], 'userid_DI': row['userid_DI'],
                                                          'video': row['video'], 'assignment': row['assignment'],
                                                          'length': row['length'], 'vote_up': row['vote_up'],
                                                          'grade': row['grade'], 'grade_category': row['grade_category']})

        # with open(self.path + 'model/comp_test_data.csv', 'w+', newline='') as f_4:
        #     fieldnames = ['course_id', 'userid_DI', 'video', 'assignment', 'length', 'vote_up', 'grade', 'grade_category']
        #     self.data_test = csv.DictWriter(f_4, fieldnames=fieldnames)
        #     self.data_test.writeheader()
        #     with open(self.path + 'MOOC_data/normal_data_all.csv', 'r') as f_5:
        #         self.normal_data = csv.DictReader(f_5)
        #         for row in self.normal_data:
        #             if 10 <= self.course_list.index(row['course_id']):
        #                         self.data_test.writerow({'course_id': row['course_id'], 'userid_DI': row['userid_DI'],
        #                                                   'video': row['video'], 'assignment': row['assignment'],
        #                                                   'length': row['length'], 'vote_up': row['vote_up'],
        #                                                   'grade': row['grade'], 'grade_category': row['grade_category']})

    def course_classify(self):
        self.path = "F:/Pycharm/paper/Learning Ability/data/MOOC/model/"
        for index, values in enumerate(self.course_list[:7]):
            with open(self.path + 'data_train/' + str(index) + '_data_train.csv', 'w+', newline='') as f:
                fieldnames = ['course_id', 'userid_DI', 'video', 'assignment', 'length', 'vote_up', 'grade', 'grade_category']
                self.data_train_classify = csv.DictWriter(f, fieldnames=fieldnames)
                self.data_train_classify.writeheader()
                with open(self.path + 'data_train.csv', 'r') as f_2:
                    self.train_data_ = csv.DictReader(f_2)
                    for row in self.train_data_:
                        if values == row['course_id']:
                            self.data_train_classify.writerow({'course_id': row['course_id'], 'userid_DI': row['userid_DI'],
                                                              'video': row['video'], 'assignment': row['assignment'],
                                                              'length': row['length'], 'vote_up': row['vote_up'],
                                                              'grade': row['grade'], 'grade_category': row['grade_category']})


if __name__ == "__main__":
    start = time.clock()
    d = raw_data_processing()
    # d.data_combine()
    # d.log_pre_processing()
    # d.forum_pre_processing()
    # d.log_processing()
    # d.forum_processing()
    # d.combine_all()
    # d.zero_mean_normalization()
    d.train_validate_test()
    # d.course_classify()
    end = time.clock()
    print("time_run:", end - start)