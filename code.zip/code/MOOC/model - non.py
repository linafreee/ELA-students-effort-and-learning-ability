import csv
import numpy as np
import pandas as pd
# import ability_9 as ability9  # 用于调节演化的参数
import ability_9_without_evolution as ability9  # 用于调节没有演化的参数
# import ability_10 as ability10  # 用于测试演化的结果
import ability_10_without_evolution as ability10  # 用于测试没有演化的结果
import ability_8 as ability8
import ability_7 as ability7
import ability_6 as ability6

import time
import my_logisticRegression1
import datetime
import json
import compared_method
import warnings

class pre_model():
    def __init__(self,iterate_tune,T_tune,lamda_a_tune,lamda_s_tune,lamda_w_tune,eta_a_tune,eta_w_tune):
        self.path = "F:/Pycharm/paper/1 Learning Ability/data/MOOC/model/"
        self.user_file = open('F:/Pycharm/paper/1 Learning Ability/data/MOOC/MOOC_data_middle/userId.json', 'r', encoding='utf-8')
        self.userId = json.load(self.user_file)
        self.userId = [str(int(i)) for i in self.userId]
        self.validate_data = pd.read_csv(self.path + "data_validate.csv")  # validate,10
        self.validate_data = pd.DataFrame(self.validate_data)
        self.train_validate_data = pd.read_csv(self.path + "data_train_validate.csv")  # 1-10
        self.train_validate_data = pd.DataFrame(self.train_validate_data)
        self.test_data = pd.read_csv(self.path + "data_test.csv")  # 11
        self.test_data = pd.DataFrame(self.test_data)
        self.iterate_tune = iterate_tune
        self.T_tune = T_tune
        self.lamda_a_tune = lamda_a_tune
        self.lamda_s_tune = lamda_s_tune
        self.lamda_w_tune = lamda_w_tune
        self.eta_a_tune = eta_a_tune
        self.eta_w_tune = eta_w_tune

    def get_effort_ability_tv(self):
        # train
        self.train_data = pd.read_csv(self.path + "data_train.csv")  # 1-9
        # self.train_data = pd.read_csv(self.path + 'tune_T/' + self.T_tune +'_train.csv')
        # effort
        self.train_effort_ability = self.train_data.ix[:, 0:2]
        self.act_weight, self.train_effort = self.get_effort(self.train_data,'train')
        self.train_effort_ability['effort'] = self.train_effort
        # ability
        a = ability9.train_ability(self.train_effort,self.train_data, self.iterate_tune,self.lamda_a_tune,self.lamda_s_tune,self.lamda_w_tune,self.eta_a_tune,self.eta_w_tune)
        self.error, self.train_ability, self.validate_ability, self.beta = a.gradient_descent()
        # print(self.error)
        self.train_effort_ability['ability'] = self.train_ability
        self.train_effort_ability['grade'] = self.train_data['grade']
        self.train_effort_ability['grade_category'] = self.train_data['grade_category']
        self.train_effort_ability.to_csv(self.path + 'middle/train_effort_ability.csv')

        # validate
        self.validate_effort_ability = self.validate_data.ix[:, 0:2]
        self.act_weight_v, self.validate_effort = self.get_effort(self.validate_data,'train')
        self.validate_effort_ability['effort'] = self.validate_effort
        self.validate_effort_ability['ability'] = self.validate_ability
        self.validate_effort_ability['grade'] = self.validate_data['grade']
        self.validate_effort_ability['grade_category'] = self.validate_data['grade_category']
        self.validate_effort_ability.to_csv(self.path + 'middle/validate_effort_ability.csv')
        return self.error

    def get_effort_ability_tvt(self):
        # train
        self.train_validate_data = pd.read_csv(self.path + "data_train_validate.csv")
        # effort
        self.train_validate_effort_ability = self.train_validate_data.ix[:, 0:2]
        self.act_weight, self.train_validate_effort = self.get_effort(self.train_validate_data,'train_validate')
        self.train_validate_effort_ability['effort'] = self.train_validate_effort
        # ability
        a = ability10.train_ability(self.train_validate_effort, self.train_validate_data, self.iterate_tune, self.lamda_a_tune,
                                  self.lamda_s_tune,self.lamda_w_tune,self.eta_a_tune,self.eta_w_tune)
        self.error, self.train_validate_ability, self.test_ability, self.beta = a.gradient_descent()
        self.train_validate_effort_ability['ability'] = self.train_validate_ability
        self.train_validate_effort_ability['grade'] = self.train_validate_data['grade']
        self.train_validate_effort_ability['grade_category'] = self.train_validate_data['grade_category']
        self.train_validate_effort_ability.to_csv(self.path + 'middle/train_validate_effort_ability.csv')

        # test
        self.test_effort_ability = self.test_data.ix[:, 0:2]
        self.act_weight_t, self.test_effort = self.get_effort(self.test_data,'train_validate')
        self.test_effort_ability['effort'] = self.test_effort
        self.test_effort_ability['ability'] = self.test_ability
        self.test_effort_ability['grade'] = self.test_data['grade']
        self.test_effort_ability['grade_category'] = self.test_data['grade_category']
        self.test_effort_ability.to_csv(self.path + 'middle/test_effort_ability.csv')
        return self.act_weight, self.beta,self.error

    def get_effort_weight(self,name):
        self.name = name
        # self.train_data = pd.read_csv(self.path + 'tune_T/' + self.T_tune +'_train.csv')  # valuate
        self.train_data = pd.read_csv(self.path + "data_" + self.name + ".csv")  # test
        self.train_data = pd.DataFrame(self.train_data)
        self.data_corr = self.train_data.ix[:, 2:7]
        self.corr = self.data_corr.corr().ix[4, 0:4]
        self.effort_weight = self.corr / self.corr.sum()
        # print(self.effort_weight)
        return self.effort_weight

    def get_effort(self, data,name):
        self.data = data
        self.name = name
        self.act_weight = self.get_effort_weight(self.name)
        self.act = self.data.ix[:, 2:6]
        self.E = np.dot(self.act, self.act_weight)
        self.E = self.E.reshape(len(self.E), 1)
        self.one = np.ones((len(self.E), 1))
        self.E = (self.E-self.one*self.E.min())/(self.E.max()-self.E.min())
        # self.E = (self.E - self.one * self.E.min())   # 8
        # print(self.E)
        return self.act_weight, self.E

    def generate_tv_data(self):
        self.train_data_all = pd.read_csv(self.path + 'middle/train_effort_ability.csv')
        self.validate_data_all = pd.read_csv(self.path + 'middle/validate_effort_ability.csv')
        self.train_classify = self.train_data_all.ix[:, [3, 4, 6]]
        self.validate_classify = self.validate_data_all.ix[:, [3, 4, 6]]
        self.train_classify.to_csv(self.path + 'my_train_for_classify.csv',index=False,header=False)
        self.validate_classify.to_csv(self.path + 'my_validate_for_classify.csv',index=False,header=False)
        m = my_logisticRegression1.logisticRegression('train','validate')
        self.result_0, self.result_1 = m.LR('evaluate')
        return self.result_0,self.result_1

    def generate_tvt_data(self):
        self.train_validate_data_all = pd.read_csv(self.path + 'middle/train_validate_effort_ability.csv')
        self.test_data_all = pd.read_csv(self.path + 'middle/test_effort_ability.csv')
        self.train_validate_classify = self.train_validate_data_all.ix[:, [3, 4, 6]]
        self.test_classify = self.test_data_all.ix[:, [3, 4, 6]]
        self.train_validate_classify.to_csv(self.path + 'my_train_validate_for_classify.csv',index=False,header=False)
        self.test_classify.to_csv(self.path + 'my_test_for_classify.csv', index=False, header=False)
        m = my_logisticRegression1.logisticRegression('train_validate','test')
        self.result_0, self.result_1 = m.LR('test')
        return self.result_0,self.result_1

class test():
    def __init__(self):
        pass

    def evaluate_model(self):
        #  超参数选择
        iterate_li = [0, 50, 100, 500, 1000, 1500, 2000]  # 1000
        # iterate_li = [0, 50, 100, 500, 1000, 1500, 2000]
        T_li = ['6','7','8','9']  # 0.6
        eta_a_li = [0.00001, 0.0001, 0.001, 0.01, 0.1]
        eta_w_li = [0.00001, 0.0001, 0.001, 0.01, 0.1]
        lamda_a_li = [0.001, 0.01, 0.1, 0.5, 1, 3, 5]
        lamda_s_li = [0.001, 0.01, 0.1, 0.5, 1, 3, 5]
        lamda_w_li = [0.001, 0.01, 0.1, 0.5, 1, 3, 5]

        T_li = ['9']
        iterate_li = [500]  # 500
        eta_a_li = [0.01]  # 0.01
        eta_w_li = [0.1]  # 0.1
        lamda_a_li = [0]  # 这里不需要
        lamda_s_li = [0]  # 这里不需要
        lamda_w_li = [5]  # 5


        for iterate in iterate_li:
            for T in T_li:
                for lamda_a in lamda_a_li:
                    for lamda_s in lamda_s_li:
                        for lamda_w in lamda_w_li:
                            for eta_a in eta_a_li:
                                for eta_w in eta_w_li:
                                    iterate_tune = iterate
                                    T_tune = T
                                    lamda_a_tune = lamda_a
                                    lamda_s_tune = lamda_s
                                    lamda_w_tune = lamda_w
                                    eta_a_tune = eta_a
                                    eta_w_tune = eta_w
                                    my_metric_list_0 = []
                                    my_metric_list_1 = []
                                    error = 0
                                    for i in range(10):
                                        p = pre_model(iterate_tune, T_tune, lamda_a_tune, lamda_s_tune,lamda_w_tune,eta_a_tune,eta_w_tune)
                                        error_this = p.get_effort_ability_tv()
                                        result_0, result_1 = p.generate_tv_data()
                                        my_metric_list_0 = my_metric_list_0 + result_0
                                        my_metric_list_1 = my_metric_list_1 + result_1
                                        error += error_this
                                    my_metric_array_0 = np.array(my_metric_list_0)
                                    my_metric_array_0 = my_metric_array_0.reshape(10, 1)
                                    my_metric_df_0 = pd.DataFrame(my_metric_array_0)
                                    my_metric_array_1 = np.array(my_metric_list_1)
                                    my_metric_array_1 = my_metric_array_1.reshape(10, 1)
                                    my_metric_df_1 = pd.DataFrame(my_metric_array_1)
                                    print('iterate:', iterate_tune, 'T:', T_tune, 'eta_a:',eta_a_tune,'eta_w:',eta_w_tune,'lamda_a:', lamda_a_tune,'lamda_s:', lamda_s_tune,'lamda_w',lamda_w_tune)
                                    # print('train_F1:', round(my_metric_df_0.mean() * 100, 2))
                                    print('test_F1:', round(my_metric_df_1.mean() * 100, 2))
                                    # print('error:', error / 10)

    def test(self):
        iterate_tune = 500
        T_tune = 1  # 0.3
        eta_a_tune = 0.01
        eta_w_tune = 0.1
        lamda_a_tune = 0
        lamda_s_tune = 0
        lamda_w_tune = 5
        my_metric_list_0 = []
        my_metric_list_1 = []
        error = 0
        for i in range(10):
            p = pre_model(iterate_tune, T_tune, lamda_a_tune, lamda_s_tune,lamda_w_tune,eta_a_tune,eta_w_tune)
            act_weight,beta,error_this = p.get_effort_ability_tvt()
            act_weight = act_weight.tolist()
            result_0, result_1 = p.generate_tvt_data()
            my_metric_list_0 = my_metric_list_0 + result_0
            my_metric_list_1 = my_metric_list_1 + result_1
            error += error_this
        my_metric_array_0 = np.array(my_metric_list_0)
        my_metric_array_0 = my_metric_array_0.reshape(10, 6)
        my_metric_df_0 = pd.DataFrame(my_metric_array_0)
        my_metric_array_1 = np.array(my_metric_list_1)
        my_metric_array_1 = my_metric_array_1.reshape(10, 6)
        my_metric_df_1 = pd.DataFrame(my_metric_array_1)
        print('iterate:', iterate_tune, 'T:', T_tune, 'eta_a:',eta_a_tune,'eta_w:',eta_w_tune,'lamda_a:', lamda_a_tune,'lamda_s:', lamda_s_tune,'lamda_w',lamda_w_tune)
        print('train_F1:', round(my_metric_df_0.mean() * 100, 2))
        print('test_F1:', round(my_metric_df_1.mean() * 100, 2))
        # print('act_weight:',act_weight,'beta:',beta)
        # print('error:', error / 10)

if __name__ == '__main__':
    start = time.clock()
    warnings.filterwarnings("ignore")
    t = test()
    # t.evaluate_model()
    t.test()
    end = time.clock()
    print("time_run:", end - start)
    print(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))