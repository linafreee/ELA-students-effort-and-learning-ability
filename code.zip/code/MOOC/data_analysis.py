import pandas as pd
import matplotlib.pyplot as plt
import numpy as np


# 绘制成绩和活动的散点图
def activity_grade():
    h = 1  # 计数，用于文件名的识别
    list = ['CB22x 2013_Spring', 'CS50x 2012', 'ER22x 2013_Spring', 'MITx 2.01x 2013_Spring',
            'MITx 3.091x 2012_Fall', 'MITx 3.091x 2013_Spring', 'MITx 6.00x 2012_Fall',
            'MITx 6.00x 2013_Spring', 'MITx 6.002x 2012_Fall', 'MITx 6.002x 2013_Spring',
            'MITx 7.00x 2013_Spring', 'MITx 8.02x 2013_Spring', 'MITx 8.MReV 2013_Summer',
            'MITx 14.73x 2013_Spring', 'PH207x 2012_Fall', 'PH278x 2013_Spring']
    for li in list:
        print(h)
        print(li)
        data = pd.read_csv('F:/Pycharm/paper1/figure_3/course_classify_3/%d/%s.csv' % (h, li))
        ar = np.array(data)
        grade = ar[:, 5]
        grade_arr = grade.toarray()
        print(grade_arr)
        print(type(grade_arr))
        activity_list = ['explored', 'nevents', 'ndays_act', 'nchapters']
        column_list = [2, 6, 7, 9]
        i = 0  # 计数，用于对子图计数
        # 用于绘制多个子图1_1,1_2,1_3
        plt.figure(figsize=(9.19, 9.19))  # 创建对象1_1
        for activity in activity_list:
            act = ar[1:, column_list[i]]
            plt.subplot(2, 2, i + 1)  # 分子图1_2
            plt.scatter(act, grade, linewidths=1, marker='.')
            plt.title(activity + ' && grade', fontsize=18)
            plt.xlabel(activity, fontsize=12)
            plt.ylabel('grade', fontsize=12)
            plt.subplots_adjust(wspace=0.3, hspace=0.3)  # 调整子图间距1_3
            # 用于保存单个图片2_1,2_2
            # plt.savefig("F:/Pycharm/paper1/figure_1/scatter_1/activity_grade/%s && grade.jpg" % activity_list[i])  # 2_1
            # plt.clf()  # 2_2
            i = i + 1
        h = h + 1


# 绘制活动和活动的散点图
def activity_activity():
    h = 1  # 计数，用于文件名的识别
    list = ['CB22x 2013_Spring', 'CS50x 2012', 'ER22x 2013_Spring', 'MITx 2.01x 2013_Spring',
            'MITx 3.091x 2012_Fall', 'MITx 3.091x 2013_Spring', 'MITx 6.00x 2012_Fall',
            'MITx 6.00x 2013_Spring', 'MITx 6.002x 2012_Fall', 'MITx 6.002x 2013_Spring',
            'MITx 7.00x 2013_Spring', 'MITx 8.02x 2013_Spring', 'MITx 8.MReV 2013_Summer',
            'MITx 14.73x 2013_Spring', 'PH207x 2012_Fall', 'PH278x 2013_Spring']
    for li in list:
        print(h)
        print(li)
        k = 0  # 计数，是第几张图。
        l = 1  # 计数，保存图片时，对名字进行区别
        data = pd.read_csv('F:/Pycharm/paper1/figure_1/course_classify_1/%d/%s.csv' % (h, li))
        ar = np.array(data)
        activity_list = ['explored', 'nevents', 'ndays_act', 'nplay_video', 'nchapters', 'nforum_posts']
        column_list = [2, 6, 7, 8, 9, 10]
        # 使每个画板放6张图
        for i in range(6):
            act_1 = ar[:, column_list[i]]
            for j in range(i+1, 6):
                if k % 6 == 0:
                    plt.figure(k, figsize=(19.2, 9.19))
                act_2 = ar[:, column_list[j]]
                plt.subplot(2, 3, k % 6 + 1)
                plt.scatter(act_1, act_2, linewidths=1, marker='.')
                plt.title('%s' % activity_list[i] + ' && ' + '%s' % activity_list[j], fontsize=18)
                plt.xlabel('%s' % activity_list[i], fontsize=12)
                plt.ylabel('%s' % activity_list[j], fontsize=12)
                plt.subplots_adjust(wspace=0.3, hspace=0.3)
                if k % 6 == 5:
                    plt.savefig('F:/Pycharm/paper1/figure_1/course_classify_1/%d/%s %d.jpg' % (h, li, l))
                    plt.clf()
                    l = l + 1
                if k == 14:
                    plt.savefig('F:/Pycharm/paper1/figure_1/course_classify_1/%d/%s %d.jpg' % (h, li, l))
                    plt.clf()
                k = k + 1
        h = h + 1


if __name__ == '__main__':
    activity_grade()
    # activity_activity()