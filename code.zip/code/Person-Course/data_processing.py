import csv
import re
import pandas as pd
import time
# MIT_edx.csv
# test_data.csv

class raw_data_processing():
    def __init__(self):
        self.path = "F:/Pycharm/paper/Learning Ability/data/MIT/"

    def remain_data(self):
        i = 1
        j = 1
        with open('remain_data.csv', 'w+', newline='') as f_2:
            # 保留：用户学的课程；用户id；学生有没有访问课件（视频、问题、exam），1为访问了，0为没有；
            # 学习超过一半的课程内容，则为1，否则为0；用户地区；性别；成绩；与课程交互次数；学生与课程互动的天数；
            # 播放视频次数；学生交互的章节数（课件内）；讨论论坛的帖子数量
            # 共10项
            fieldnames = ['course_id', 'userid_DI', 'viewed', 'explored', 'final_cc_cname_DI',
                          'gender', 'grade', 'nevents', 'ndays_act', 'nplay_video',
                          'nchapters', 'nforum_posts']
            remain_d = csv.DictWriter(f_2, fieldnames=fieldnames)
            remain_d.writeheader()
            # 读原始数据
            with open('MIT_edx.csv', 'r') as f_1:
                initial_reader = csv.DictReader(f_1)
                for row in initial_reader:
                    print('j:', j)
                    print(row)
                    print(row['grade'])
                    j = j + 1
                    if row['grade'] == '0':  # 成绩为0的数据
                        print('0')
                    elif row['grade'] == '1.01':  # 成绩为1.01的数据
                        print('1.01')
                    elif row['grade'] == '':  # 成绩为空的数据
                        print('Null')
                    elif row['grade'] == ' ':  # 成绩为空的数据
                        print('Null')
                    else:
                        print(i)
                        print('OK')
                        # 写入csv
                        remain_d.writerow({'course_id': row['course_id'], 'userid_DI': row['userid_DI'], 'viewed':
                                                row['viewed'], 'explored': row['explored'],
                                               'final_cc_cname_DI': row['final_cc_cname_DI'],
                                               'gender': row['gender'], 'grade': row['grade'], 'nevents':
                                                   row['nevents'], 'ndays_act': row['ndays_act'], 'nplay_video'
                                               : row['nplay_video'], 'nchapters': row['nchapters'], 'nforum_posts'
                                               : row['nforum_posts']})
                        i = i + 1

    def supplementary_data(self):
        i = 1
        j = 1
        with open('supplementary_data.csv', 'w+', newline='') as f_4:
            fieldnames = ['course_id', 'userid_DI', 'viewed', 'explored', 'final_cc_cname_DI',
                          'gender', 'grade', 'nevents', 'ndays_act', 'nplay_video',
                          'nchapters', 'nforum_posts']
            supplementary_d = csv.DictWriter(f_4, fieldnames=fieldnames)
            supplementary_d.writeheader()
            with open('remain_data.csv', 'r') as f_3:
                remain_reader = csv.DictReader(f_3)
                for row in remain_reader:
                    print('j:', j)
                    print(row)
                    j = j + 1
                    # 将空数据置为0
                    if row['nevents'] == '':
                        print('nevents is Null')
                        row['nevents'] = '0'
                    if row['ndays_act'] == '':
                        print('ndays_act is Null')
                        row['ndays_act'] = '0'
                    if row['nplay_video'] == '':
                        print('nplay_video is Null')
                        row['nplay_video'] = '0'
                    if row['nchapters'] == '':
                        print('nchapters is Null')
                        row['nchapters'] = '0'
                    print(i)
                    supplementary_d.writerow({'course_id': row['course_id'], 'userid_DI': row['userid_DI'], 'viewed':
                                                row['viewed'], 'explored': row['explored'],
                                               'final_cc_cname_DI': row['final_cc_cname_DI'],
                                               'gender': row['gender'], 'grade': row['grade'], 'nevents':
                                                   row['nevents'], 'ndays_act': row['ndays_act'], 'nplay_video'
                                               : row['nplay_video'], 'nchapters': row['nchapters'], 'nforum_posts'
                                               : row['nforum_posts']})
                    i = i + 1

    def count_userid(self):
        li1 = 0
        li2 = 0
        li3 = 0
        j = 0
        list_1 = []  # 出现1次及以上
        list_2 = []  # 出现2次及以上
        list_3 = []  # 出现3次及以上
        with open('supplementary_data.csv', 'r') as f_5:
            remain_reader = csv.DictReader(f_5)
            for row in remain_reader:
                print(row['userid_DI'])
                print(j)
                j = j + 1
                for li_1 in list_1:  # 是否在表1中出现过
                    if li_1 == row['userid_DI']:
                        li1 = 1  # 在表1中出现过，本次至少为第2次；不需再向表1中添加。
                        for li_2 in list_2:  # 本次是否在表2中出现过
                            if li_2 == row['userid_DI']:
                                li2 = 1  # 在表2中出现过，本次至少为第3次；已添加到了表2
                                for li_3 in list_3:  # 是否已添加到表3，防止重复
                                    if li_3 == row['userid_DI']:  # 已加入表3，不要再重复加入
                                        li3 = 1
                                        break
                                if li3 == 0:  # 出现了3次，却未添加到表3，需添加到表3
                                    list_3.append(row['userid_DI'])
                                    f_3 = open("userId_3.txt", "a+")
                                    f_3.write(row['userid_DI'] + "\n")
                                break  # 是否添加到表3处理完了
                            li3 = 0
                        if li2 == 0:  # 在表1中出现过，未在表2中出现，出现了3次，添加到表2
                            list_2.append(row['userid_DI'])
                            f_2 = open("userId_2.txt", "a+")
                            f_2.write(row['userid_DI'] + "\n")
                        break
                    li2 = 0
                if li1 == 0:  # 未在表1中出现，只出现了1次，添加到表1
                    list_1.append(row['userid_DI'])
                    f_1 = open("userId_1.txt", "a+")
                    f_1.write(row['userid_DI'] + "\n")
                li1 = 0
        print(len(list_1))
        print(len(list_2))
        print(len(list_3))

    def userid_data(self):
        # 修改文件名，更改数字
        # 根据学生学习的课程数目，分开存储数据。
        j = 1
        with open('userId_data_1.csv', 'w+', newline='') as f_1:
            fieldnames = ['course_id', 'userid_DI', 'viewed', 'explored', 'final_cc_cname_DI',
                          'gender', 'grade', 'nevents', 'ndays_act', 'nplay_video',
                          'nchapters', 'nforum_posts']
            userId = csv.DictWriter(f_1, fieldnames=fieldnames)
            userId.writeheader()
            with open("userId_2.txt", 'r') as f:
                lines = f.readlines()
                f.close()
            with open('supplementary_data.csv', 'r') as f_2:
                remain_reader = csv.DictReader(f_2)
                for row in remain_reader:
                    for line in lines:
                        line = re.sub(r'\n', '', line)
                        if line == row['userid_DI']:
                            # 查询该用户学生是否在txt
                            print(j)
                            print('find', line)
                            print(line)
                            j = j + 1
                            userId.writerow({'course_id': row['course_id'], 'userid_DI': row['userid_DI'], 'viewed':
                                                 row['viewed'], 'explored': row['explored'],
                                                 'final_cc_cname_DI': row['final_cc_cname_DI'],
                                                 'gender': row['gender'], 'grade': row['grade'], 'nevents':
                                                     row['nevents'], 'ndays_act': row['ndays_act'], 'nplay_video'
                                                 : row['nplay_video'], 'nchapters': row['nchapters'], 'nforum_posts'
                                                 : row['nforum_posts']})
                            break

    def get_course_list(self):
        course_list = []
        with open(self.path + "userId_data_3.csv", 'r') as f_1:
            reader = csv.DictReader(f_1)
            for row in reader:
                course_id = row['course_id']
                print(course_id)
                if course_id not in course_list:
                    f_2 = open(self.path + "courseId_3.txt", "a+")
                    f_2.write(course_id + "\n")
                    course_list.append(course_id)
            print(len(course_list))

class final_data_processing():
    def __init__(self):
        self.path = "F:/Pycharm/paper/Learning Ability/data/MIT/MIT_data/"
        self.course_list = ['MITx/3.091x/2012_Fall', 'MITx/6.00x/2012_Fall', 'MITx/6.002x/2012_Fall',
                            'HarvardX/PH207x/2012_Fall', 'HarvardX/CB22x/2013_Spring', 'HarvardX/ER22x/2013_Spring',
                            'HarvardX/PH278x/2013_Spring', 'MITx/2.01x/2013_Spring', 'MITx/3.091x/2013_Spring',
                            'MITx/6.00x/2013_Spring', 'MITx/6.002x/2013_Spring', 'MITx/7.00x/2013_Spring',
                            'MITx/8.02x/2013_Spring', 'MITx/14.73x/2013_Spring', 'MITx/8.MReV/2013_Summer']
        self.reversed_course_list = list(reversed(self.course_list))

    def zero_mean_normalization(self):
        self.raw_data = pd.read_csv(self.path + 'data_all.csv')
        self.raw_data = pd.DataFrame(self.raw_data)
        self.raw_data['explored'] = (self.raw_data['explored'] - self.raw_data['explored'].min()) / \
                                 (self.raw_data['explored'].max() - self.raw_data['explored'].min())
        self.raw_data['nevents'] = (self.raw_data['nevents'] - self.raw_data['nevents'].min()) / \
                                 (self.raw_data['nevents'].max() - self.raw_data['nevents'].min())
        self.raw_data['ndays_act'] = (self.raw_data['ndays_act'] - self.raw_data['ndays_act'].min()) / \
                                 (self.raw_data['ndays_act'].max() - self.raw_data['ndays_act'].min())
        self.raw_data['nplay_video'] = (self.raw_data['nplay_video'] - self.raw_data['nplay_video'].min()) / \
                                 (self.raw_data['nplay_video'].max() - self.raw_data['nplay_video'].min())
        self.raw_data['nchapters'] = (self.raw_data['nchapters'] - self.raw_data['nchapters'].min()) / \
                                       (self.raw_data['nchapters'].max() - self.raw_data['nchapters'].min())
        self.raw_data['nforum_posts'] = (self.raw_data['nforum_posts'] - self.raw_data['nforum_posts'].min()) / \
                                       (self.raw_data['nforum_posts'].max() - self.raw_data['nforum_posts'].min())
        self.raw_data.to_csv(self.path + 'normal_data_all.csv')
        
    def train_test(self):
        with open(self.path + "userId.txt", 'r') as f:
            lines = f.readlines()
            f.close()
        with open(self.path + 'data_test.csv', 'w+', newline='') as f_1:
            fieldnames = ['course_id', 'userid_DI', 'explored', 'nevents', 'ndays_act', 'nplay_video', 'nchapters',
                          'nforum_posts', 'grade', 'grade_category']
            self.data_train = csv.DictWriter(f_1, fieldnames=fieldnames)
            self.data_train.writeheader()
            for line in lines:
                line = re.sub(r'\n', '', line)
                i = 0
                with open(self.path + 'data_all.csv', 'r') as f_2:
                    self.reversed_data = csv.DictReader(f_2)
                    for row in self.reversed_data:
                        if line == row['userid_DI']:
                            i += 1
                            if 2 < i < 4:
                                self.data_train.writerow({'course_id': row['course_id'], 'userid_DI': row['userid_DI'],
                                                         'explored': row['explored'], 'nevents': row['nevents'],
                                                          'ndays_act': row['ndays_act'], 'nplay_video': row['nplay_video'],
                                                          'nchapters': row['nchapters'], 'nforum_posts': row['nforum_posts'],
                                                          'grade': row['grade'], 'grade_category': row['grade_category']})

        # with open(self.path + 'data_validate.csv', 'w+', newline='') as f_3:
        #     fieldnames = ['course_id', 'userid_DI', 'explored', 'nevents', 'ndays_act', 'nplay_video', 'nchapters',
        #                   'nforum_posts', 'grade', 'grade_category']
        #     self.data_test = csv.DictWriter(f_3, fieldnames=fieldnames)
        #     self.data_test.writeheader()
        #     for line in lines:
        #         line = re.sub(r'\n', '', line)
        #         i = 0
        #         with open(self.path + 'data_all.csv', 'r') as f_4:
        #             self.reversed_data = csv.DictReader(f_4)
        #             for row in self.reversed_data:
        #                 if line == row['userid_DI']:
        #                     i += 1
        #                     if 2 <= i < 3:
        #                         self.data_test.writerow({'course_id': row['course_id'], 'userid_DI': row['userid_DI'],
        #                                                 'explored': row['explored'], 'nevents': row['nevents'],
        #                                                  'ndays_act': row['ndays_act'], 'nplay_video': row['nplay_video'],
        #                                                  'nchapters': row['nchapters'], 'nforum_posts': row['nforum_posts'],
        #                                                  'grade': row['grade'], 'grade_category': row['grade_category']})

# 按课程名，将数据分开
    def course_classify(self):
        self.path = "F:/Pycharm/paper/Learning Ability/data/MIT/model/"
        for index, values in enumerate(self.course_list):
            with open(self.path + 'data_train/' + str(index) + '_data_train.csv', 'w+', newline='') as f:
                fieldnames = ['course_id', 'userid_DI', 'explored', 'nevents', 'ndays_act', 'nplay_video', 'nchapters',
                              'nforum_posts', 'grade', 'grade_category']
                self.data_train_classify = csv.DictWriter(f, fieldnames=fieldnames)
                self.data_train_classify.writeheader()
                with open(self.path + 'data_train.csv', 'r') as f_2:
                    self.train_data_ = csv.DictReader(f_2)
                    for row in self.train_data_:
                        if values == row['course_id']:
                            self.data_train_classify.writerow({'course_id': row['course_id'], 'userid_DI': row['userid_DI'],
                                                    'explored': row['explored'], 'nevents': row['nevents'],
                                                     'ndays_act': row['ndays_act'], 'nplay_video': row['nplay_video'],
                                                     'nchapters': row['nchapters'], 'nforum_posts': row['nforum_posts'],
                                                     'grade': row['grade'], 'grade_category': row['grade_category']})


    def count_uid(self):
        self.user_all =[]
        self.user_3 = []
        self.user_4 = []
        self.user_5 = []
        with open(self.path + 'normal_data_all.csv', 'r') as f_1:
            self.data_all = csv.DictReader(f_1)
            for row1 in self.data_all:
                self.user_all.append(row1['userid_DI'])
        for user in self.user_all:
            if self.user_all.count(user) >= 3 and user not in self.user_3:
                self.user_3.append(user)
                f_3 = open(self.path + "userId_3.txt", "a+")
                f_3.write(user + "\n")
            if self.user_all.count(user) >= 4 and user not in self.user_4:
                self.user_4.append(user)
                f_4 = open(self.path + "userId_4.txt", "a+")
                f_4.write(user + "\n")
            if self.user_all.count(user) >= 5 and user not in self.user_5:
                self.user_5.append(user)
                f_5 = open(self.path + "userId_5.txt", "a+")
                f_5.write(user + "\n")
        print(len(self.user_3))
        print(len(self.user_4))
        print(len(self.user_5))
        with open(self.path + 'data_user_5.csv', 'w+', newline='') as f:
            fieldnames = ['course_id', 'userid_DI', 'explored', 'nevents', 'ndays_act', 'nplay_video', 'nchapters',
                          'nforum_posts', 'grade', 'grade_category']
            self.data_u = csv.DictWriter(f, fieldnames=fieldnames)
            self.data_u.writeheader()
            for user in self.user_5:
                self.count = 0
                with open(self.path + 'normal_data_all.csv', 'r') as f_2:
                    self.data_al = csv.DictReader(f_2)
                    for row in self.data_al:
                        if user == row['userid_DI']:
                            self.count += 1
                            if self.count <= 5:
                                self.data_u.writerow(
                                    {'course_id': row['course_id'], 'userid_DI': row['userid_DI'],
                                     'explored': row['explored'], 'nevents': row['nevents'],
                                     'ndays_act': row['ndays_act'], 'nplay_video': row['nplay_video'],
                                     'nchapters': row['nchapters'], 'nforum_posts': row['nforum_posts'],
                                     'grade': row['grade'], 'grade_category': row['grade_category']})


class data_for_metric():
    def __init__(self):
        self.path = "F:/Pycharm/paper/Learning Ability/data/MIT/metric/"

    def data_for_compare(self):
        with open(self.path + 'data_all.csv', 'w+', newline='') as f:  # test
            self.fieldnames = ['course_id', 'userid_DI', 'explored', 'nevents', 'ndays_act', 'nplay_video', 'nchapters', 'nforum_posts', 'grade', 'grade_category']
            self.compared_data = csv.DictWriter(f, fieldnames=self.fieldnames)
            self.compared_data.writeheader()
            with open('F:/Pycharm/paper/Learning Ability/data/MIT/MIT_data/course_all.csv', 'r') as f_1:  # test
                self.compared_all = csv.DictReader(f_1)
                for row in self.compared_all:
                    self.grade = float(row['grade'])
                    if 0 <= self.grade < 0.2:
                        self.grade_category = 'E'
                    elif self.grade < 0.4:
                        self.grade_category = 'D'
                    elif self.grade < 0.6:
                        self.grade_category = 'C'
                    elif self.grade < 0.8:
                        self.grade_category = 'B'
                    else:
                        self.grade_category = 'A'
                    self.compared_data.writerow({'course_id': row['course_id'], 'userid_DI': row['userid_DI'],
                                                 'explored': row['explored'],  'nevents': row['nevents'], 'ndays_act': row['ndays_act'],
                                                 'nplay_video': row['nplay_video'], 'nchapters': row['nchapters'],
                                                 'nforum_posts': row['nforum_posts'], 'grade': row['grade'], 'grade_category': self.grade_category})


if __name__ == '__main__':
    start = time.clock()
    # remain_data()  # 删除成绩为0的数据，空数据和成绩为1.01的数据，74339条数据。
    # supplementary_data()  # 将空白数据置为了0。
    # count_userid()  # 根据学生学习课程的数目,区分学生。数目为至少学习几个课程。
    # userid_data()  # 根据学生学习的课程数目，分开存储数据。
    # get_course_list()  # 获取需要用户学习的所有课程,即所有课程
    f = final_data_processing()
    # f.get_reversed_data_all()
    f.train_test()  # 分开训练集和测试集
    # f.course_classify()  # 按照学习课程的不同，分开存储数据。
    # f.count_uid()
    # m = data_for_metric()
    # m.data_for_compare()  # 为评估生成数据集
    # m.zero_mean_normalization()
    end = time.clock()
    print("time_run:", end - start)