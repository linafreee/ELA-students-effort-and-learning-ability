import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.pipeline import Pipeline
from sklearn import svm
from keras.models import Sequential
from keras.layers import Dense, Dropout
from keras.wrappers.scikit_learn import KerasClassifier
import evaluate
import time
from sklearn.model_selection import cross_val_score
import numpy as np
import warnings
import datetime

class method():
    def __init__(self,feature_num):
        self.path = "F:/Pycharm/paper/Learning Ability/data/MIT/model/comp/"
        self.feature_num = feature_num

        # 调节参数数据
        self.train_validate_x = pd.read_csv(self.path + 'comp_train_x.csv', header=None)
        self.test_x = pd.read_csv(self.path + 'comp_validate_x.csv', header=None)
        self.train_validate_y = pd.read_csv(self.path + 'comp_train_y.csv', header=None)
        self.test_y = pd.read_csv(self.path + 'comp_validate_y.csv', header=None)

        # # 测试数据
        # self.train_validate_x = pd.read_csv(self.path + 'comp_train_validate_x.csv', header=None)
        # self.test_x = pd.read_csv(self.path + 'comp_test_x.csv', header=None)
        # self.train_validate_y = pd.read_csv(self.path + 'comp_train_validate_y.csv', header=None)
        # self.test_y = pd.read_csv(self.path + 'comp_test_y.csv', header=None)

        self.train_validate_x = self.train_validate_x.values
        self.test_x = self.test_x.values
        self.train_validate_y = self.train_validate_y.values
        self.test_y = self.test_y.values

        self.train_validate_y = self.train_validate_y.flatten()

    def LR(self):
        self.lr = Pipeline([
                            ('poly', PolynomialFeatures(degree=self.feature_num)),
                            ('clf', LogisticRegression(C=100))])  # 100
        self.lr.fit(self.train_validate_x, self.train_validate_y)
        self.train_validate_hat = self.lr.predict(self.train_validate_x)
        self.test_hat = self.lr.predict(self.test_x)
        e = evaluate.evaluate()
        self.e_0 = e.metric(self.train_validate_y, self.train_validate_hat, 'test')
        self.e_1 = e.metric(self.test_y, self.test_hat, 'test')
        return self.e_0, self.e_1

    def SVM(self):
        self.clf = svm.SVC(C=100, kernel='rbf', decision_function_shape='ovr')  # 100
        self.clf.fit(self.train_validate_x, self.train_validate_y)
        self.train_validate_hat = self.clf.predict(self.train_validate_x)
        self.test_hat = self.clf.predict(self.test_x)
        e = evaluate.evaluate()
        self.e_0 = e.metric(self.train_validate_y, self.train_validate_hat, 'test')
        self.e_1 = e.metric(self.test_y, self.test_hat, 'test')
        return self.e_0, self.e_1

    def NN(self):
        self.clf = KerasClassifier(build_fn=self.NN_baseline_model, nb_epoch=20, batch_size=20)
        self.clf.fit(self.train_validate_x, self.train_validate_y)
        self.train_validate_hat = self.clf.predict(self.train_validate_x)
        self.test_hat = self.clf.predict(self.test_x)
        e = evaluate.evaluate()
        self.e_0 = e.metric(self.train_validate_y, self.train_validate_hat, 'test')
        self.e_1 = e.metric(self.test_y, self.test_hat, 'test')
        return self.e_0, self.e_1

    def NN_baseline_model(self):
        model = Sequential()
        model.add(Dense(output_dim=30, input_dim=self.feature_num, activation='relu'))
        model.add(Dropout(0.2))
        model.add(Dense(output_dim=5, input_dim=30, activation='softmax'))
        # Compile model
        model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
        return model


if __name__ == '__main__':
    start = time.clock()
    warnings.filterwarnings("ignore")
    my_metric_list_0 = []
    my_metric_list_1 = []
    for i in range(10):
        m = method(6)
        e_0, e_1 = m.LR()
        # e_0, e_1 = m.SVM()
        # e_0, e_1 = m.NN()
        my_metric_list_0 = my_metric_list_0 + e_0
        my_metric_list_1 = my_metric_list_1 + e_1
    my_metric_array_0 = np.array(my_metric_list_0)
    my_metric_array_0 = my_metric_array_0.reshape(10, 6)
    my_metric_df_0 = pd.DataFrame(my_metric_array_0)
    print(round(my_metric_df_0.mean() * 100, 2))
    my_metric_array_1 = np.array(my_metric_list_1)
    my_metric_array_1 = my_metric_array_1.reshape(10, 6)
    my_metric_df_1 = pd.DataFrame(my_metric_array_1)
    print(round(my_metric_df_1.mean() * 100, 2))
    end = time.clock()
    print("time_run:", end - start)
    print(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))