import numpy as np
import random
import math

class train_ability():
    def __init__(self, effort_data,train_data,iterate,lamda_a,lamda_s,lamda_w,eta_a,eta_w):
        self.train_data = train_data
        # print("init...")  # X*W=y_pred (m*2)*(2,1)=(m*1)
        # weight
        self.W = np.random.rand(2, 1)  # 学习;分别为努力和学习能力的权重
        self.beta = random.random()  # 学习-输出
        # effort
        self.E = effort_data
        self.E = self.E.reshape(len(self.E), 1)  # 定值，与A组合成矩阵
        # ability
        self.A = np.random.rand(len(self.E), 1)  # 学习
        # X=(E,A) m*2
        self.X = np.hstack((self.E, self.A))
        # grade y
        self.y = self.train_data.ix[:, 8:9]
        self.y = self.y.values
        self.y = self.y.reshape(len(self.y), 1)
        # The Learning Rate eta
        self.eta_a = eta_a  # 步长
        self.eta_w = eta_w
        self.iterate_tune = iterate
        self.iterate = 0
        self.lamda_w = lamda_w  # 定值
        self.lamda_a = lamda_a  # 超参数,需要分析
        self.lamda_s = lamda_s  # 超参数,需要分析



    def gradient_descent(self):
        # print("gradient_descent...")
        self.gradient_A = self.gradient_function_E_step(self.W, self.X, self.y)  # m*1
        while self.iterate < self.iterate_tune:
            self.A = self.A - self.eta_a * self.gradient_A
            self.X = np.hstack((self.E, self.A))
            self.gradient_W = self.gradient_function_M_step(self.W, self.X, self.y)  # m*1 # 3*1
            # M步
            self.W = self.W - self.eta_w * self.gradient_W
            self.gradient_A = self.gradient_function_E_step(self.W, self.X, self.y)
            self.iterate += 1

        self.error = self.loss_function(self.W, self.X, self.y)
        self.A_T0, self.A_T1 = self.get_ability_split(self.A)
        self.A_T2 = np.random.rand(len(self.A_T1), 1)
        for i in range(0, len(self.A_T1)):
            self.A_T2[i][0] = (self.A_T0[i][0]+self.A_T1[i][0])/2
        return self.error, self.A,self.A_T2,self.beta


    # 按时间(课程)拆分学习能力
    def get_ability_split(self, A):
        self.A = A
        self.T = 2
        self.A_T0 = np.random.rand(int(len(self.A)/self.T), 1)
        self.A_T1 = np.random.rand(int(len(self.A)/self.T), 1)
        for i in range(len(self.A)):
            if i % self.T == 0:
                self.A_T0[int(i/self.T)][0] = self.A[i][0]
            if i % self.T == 1:
                self.A_T1[int(i/self.T)][0] = self.A[i][0]
        return self.A_T0, self.A_T1

    def gradient_function_E_step(self, W, X, y):  # 固定W,更新A
        '''Gradient of the function J definition.'''
        self.W = W
        self.X = X
        self.y = y
        self.diff = np.dot(self.X, self.W) - self.y  # m*1
        self.gradient_A = np.dot(self.diff, self.W[1].reshape(1, 1))
        return self.gradient_A

    def gradient_function_M_step(self, W, X, y):  # 固定X,更新W
        '''Gradient of the function J definition.'''
        self.W = W
        self.X = X
        self.y = y
        self.diff = np.dot(self.X,self.W) - self.y  # m*1
        self.W = np.absolute(self.W)
        self.gradient_W = np.dot(np.transpose(self.X), self.diff) / len(self.E) + self.lamda_w * self.W  # (2*m)*(m*1)
        return self.gradient_W

    def loss_function(self, W, X, y):
        '''Error function J definition.'''
        self.W = W
        self.X = X
        self.y = y
        self.diff = np.dot(self.X,self.W) - self.y
        self.loss = 1. / (2 * len(self.E)) * np.dot(np.transpose(self.diff), self.diff) + self.lamda_w / 2 * np.dot(np.transpose(self.W), self.W)
        return self.loss


if __name__ == '__main__':
    pass
