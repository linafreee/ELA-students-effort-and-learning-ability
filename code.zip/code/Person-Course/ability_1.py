import numpy as np
import random
import math

class train_ability():
    def __init__(self, effort_data,train_data,iterate,lamda_a,lamda_s,lamda_w,eta_a,eta_w):
        self.train_data = train_data
        # print("init...")  # X*W=y_pred (m*2)*(2,1)=(m*1)
        # weight
        self.W = np.random.rand(2, 1)  # 学习;分别为努力和学习能力的权重
        self.beta = random.random()  # 学习-输出
        # effort
        self.E = effort_data
        self.E = self.E.reshape(len(self.E), 1)  # 定值，与A组合成矩阵
        # ability
        self.A = np.random.rand(len(self.E), 1)  # 学习
        # X=(E,A) m*2
        self.X = np.hstack((self.E, self.A))
        # grade y
        self.y = self.train_data.ix[:, 8:9]
        self.y = self.y.values
        self.y = self.y.reshape(len(self.y), 1)
        # The Learning Rate eta
        self.eta_a = eta_a  # 步长
        self.eta_w = eta_w
        self.iterate_tune = iterate
        self.iterate = 0
        self.lamda_w = lamda_w  # 定值 w
        self.lamda_a = lamda_a  # 超参数,需要分析 beta
        self.lamda_s = lamda_s  # 超参数,需要分析



    def gradient_descent(self):
        # print("gradient_descent...")
        self.gradient_A = self.gradient_function_E_step(self.W, self.X, self.y,self.A)  # m*1
        while self.iterate < self.iterate_tune:
            self.A = self.A - self.eta_a * self.gradient_A
            self.X = np.hstack((self.E, self.A))
            self.gradient_W, self.gradient_beta = self.gradient_function_M_step(self.W, self.X, self.y)  # m*1 # 3*1
            # M步
            self.W = self.W - self.eta_w * self.gradient_W
            self.beta = self.beta - self.eta_w * self.gradient_beta
            self.gradient_A = self.gradient_function_E_step(self.W, self.X, self.y, self.A)
            self.iterate += 1

        self.error = self.loss_function(self.W, self.A, self.X, self.y,self.beta)
        self.A_T1 = self.A
        return self.error, self.A,self.A_T1,self.beta

    def gradient_function_E_step(self, W, X, y,A):  # 固定W,更新X
        '''Gradient of the function J definition.'''
        self.W = W
        self.X = X
        self.y = y
        self.A = A
        self.diff = np.dot(self.X, self.W) - self.y  # m*1
        self.gradient_A = np.dot(self.diff, self.W[1].reshape(1,1))
        return self.gradient_A

    def gradient_function_M_step(self, W, X, y):  # 固定X,更新W
        '''Gradient of the function J definition.'''
        self.W = W
        self.X = X
        self.y = y
        self.diff = np.dot(self.X,self.W) - self.y  # m*1
        self.W = np.absolute(self.W)
        self.gradient_W = np.dot(np.transpose(self.X), self.diff)/len(self.E) + self.lamda_w*self.W  # (2*m)*(m*1)
        self.gradient_beta = 0
        return self.gradient_W, self.gradient_beta

    def loss_function(self, W, A, X, y,beta):
        '''Error function J definition.'''
        self.W = W
        self.beta = beta
        self.X = X
        self.y = y
        self.A = A
        self.diff = np.dot(self.X,self.W) - self.y
        return 1. / (2*len(self.E)) * np.dot(np.transpose(self.diff), self.diff) + \
               self.lamda_w / 2 * np.dot(np.transpose(self.W), self.W)


if __name__ == '__main__':
    pass
