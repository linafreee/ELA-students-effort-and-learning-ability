import matplotlib.pyplot as plt
import time
import numpy as np
from scipy.interpolate import spline
from scipy import interpolate

class plt_parameter_analysis():
    def __init__(self):
        self.path = 'E:/dearling/Papers/1 Learning ability/图/'
        self.font_x = {'family': 'Arial',
                        'color': '#000000',
                        'weight': 'normal',
                        'size': 15,
                        }
        self.font_y1 = {'family': 'Arial',
                   'color': 'r',
                   'weight': 'normal',
                   'size': 15,
                   }
        self.font_y2 = {'family': 'Arial',
                   'color': 'b',
                   'weight': 'normal',
                   'size': 15,
                   }

    def iterate_F1(self):
        self.L = [0, 1, 2, 3, 4, 5]
        self.Macro_F1 = [0.1935, 0.1927, 0.1931, 0.1827, 0.1777, 0.1777]
        self.Micro_F1 = [0.7230, 0.7230, 0.7230, 0.7184, 0.7138, 0.7148]
        fig = plt.figure(figsize=(12, 4), facecolor='w')
        ax = fig.add_subplot(121)
        lns1 = ax.plot(self.L, self.Macro_F1, 'D-', linestyle='dashed', markersize=6, c='r', lw=2.5,
                       alpha=0.8, label='Macro_F1')
        ax.tick_params(axis='y', colors='r', direction='in')
        plt.ylim(0.177, 0.195)
        plt.yticks([0.177, (0.177 + 0.195)/2, 0.195])
        ax2 = ax.twinx()
        lns2 = ax2.plot(self.L, self.Micro_F1, '*-', linestyle='solid', markersize=10, c='b', lw=2.5,
                        alpha=0.8,
                        label='Micro_F1')
        ax2.tick_params(axis='y', colors='b', direction='in')
        plt.ylim(0.712,0.724)
        plt.yticks([0.712, (0.712+0.724)/2,0.724])
        lns = lns1 + lns2
        labs = [l.get_label() for l in lns]
        ax.legend(lns, labs)
        ax.tick_params(direction='in')
        plt.xticks([0, 1, 2, 3, 4, 5], [0, 100, 500, 1000, 1500, 2000])
        ax.set_ylabel('Macro_F1', fontdict=self.font_y1)
        ax2.set_ylabel('Micro_F1', fontdict=self.font_y2)
        ax.set_xlabel(r'$L$', self.font_x)
        plt.xlim(np.min(self.L), np.max(self.L))
        # plt.title('$L$', fontsize=15)

        plt.tight_layout()
        plt.subplots_adjust(left=None, bottom=None, right=None, top=None,
                            wspace=0.4, hspace=None)
        plt.savefig(self.path + 'L.png', dpi=300)
        plt.show()

    def eta_F1(self):
        self.eta_a = [1, 2, 3, 4, 5]
        self.eta_w = [1, 2, 3, 4, 5]
        self.eta_a_Macro_F1 = [0.2049, 0.1967, 0.1924, 0.1865, 0.1750]
        self.eta_a_Micro_F1 = [0.7291, 0.7247, 0.7230, 0.7196, 0.7131]
        self.eta_w_Macro_F1 = [0.1969, 0.1885, 0.1748, 0.1922, 0.1726]
        self.eta_w_Micro_F1 = [0.7249, 0.7201, 0.7121, 0.7230, 0.7119]  # 创建图并命名
        fig = plt.figure(figsize=(12, 4), facecolor='w')
        ax = fig.add_subplot(121)
        lns1 = ax.plot(self.eta_a, self.eta_a_Macro_F1, 'D-', linestyle='dashed', markersize=6, c='r', lw=2.5,
                       alpha=0.8, label='Macro_F1')
        ax.tick_params(axis='y', colors='r', direction='in')
        plt.ylim(0.174, 0.207)
        plt.yticks([0.174, (0.174 + 0.207) / 2, 0.207])
        ax2 = ax.twinx()
        lns2 = ax2.plot(self.eta_a, self.eta_a_Micro_F1, '*-', linestyle='solid', markersize=10, c='b', lw=2.5,
                        alpha=0.8,
                        label='Micro_F1')
        ax2.tick_params(axis='y', colors='b', direction='in')
        plt.ylim(0.712, 0.730)
        plt.yticks([0.712, (0.712 + 0.730) / 2, 0.730])
        lns = lns1 + lns2
        labs = [l.get_label() for l in lns]
        ax.legend(lns, labs)
        ax.tick_params(direction='in')
        plt.xticks([1, 2, 3, 4, 5], [0.00001, 0.0001, 0.001, 0.01, 0.1])
        ax.set_ylabel('Macro_F1', fontdict=self.font_y1)
        ax2.set_ylabel('Micro_F1', fontdict=self.font_y2)
        ax.set_xlabel(r'$\eta_a$', self.font_x)
        plt.xlim(np.min(self.eta_a), np.max(self.eta_a))
        # plt.title('(a) $\eta_a$', fontsize=15)

        ax = fig.add_subplot(122)
        lns1 = ax.plot(self.eta_w, self.eta_w_Macro_F1, 'D-', linestyle='dashed', markersize=6, c='r', lw=2.5,
                       alpha=0.8, label='Macro_F1')
        ax.tick_params(axis='y', colors='r', direction='in')
        plt.ylim(0.170, 0.200)
        plt.yticks([0.170, (0.170+0.200)/2, 0.200])
        ax2 = ax.twinx()
        lns2 = ax2.plot(self.eta_w, self.eta_w_Micro_F1, '*-', linestyle='solid', markersize=10, c='b', lw=2.5,
                        alpha=0.8,
                        label='Micro_F1')
        ax2.tick_params(axis='y', colors='b', direction='in')
        plt.ylim(0.710, 0.726)
        plt.yticks([0.710, (0.710 + 0.726) / 2, 0.726])
        lns = lns1 + lns2
        labs = [l.get_label() for l in lns]
        ax.legend(lns, labs)
        plt.xticks([1, 2, 3, 4, 5], [0.00001, 0.0001, 0.001, 0.01, 0.1])
        ax.set_ylabel('Macro_F1', fontdict=self.font_y1)
        ax2.set_ylabel('Micro_F1', fontdict=self.font_y2)
        ax.set_xlabel(r'$\eta_w$', self.font_x)
        plt.xlim(np.min(self.eta_w), np.max(self.eta_w))
        # plt.title('(b) $\eta_w$', fontsize=15)

        plt.tight_layout()
        plt.subplots_adjust(left=None, bottom=None, right=None, top=None,
                            wspace=0.4, hspace=None)
        plt.savefig(self.path + 'eta.png', dpi=300)
        plt.show()

    def lambda_F1(self):
        self.lambda_a = [1, 2, 3, 4, 5, 6, 7]
        self.lambda_s = [1, 2, 3, 4, 5, 6, 7]
        self.lambda_w = [1, 2, 3, 4, 5, 6, 7]
        self.lambda_a_Macro_F1 = [0.1726, 0.1724, 0.1835, 0.1824, 0.1910, 0.1746, 0.1753]
        self.lambda_a_Micro_F1 = [0.7119, 0.7119, 0.7169, 0.7172, 0.7191, 0.7121, 0.7133]
        self.lambda_s_Macro_F1 = [0.1923, 0.1867, 0.1922, 0.1936, 0.1772, 0.1757, 0.1727]
        self.lambda_s_Micro_F1 = [0.7220, 0.7196, 0.7228, 0.7220, 0.7143, 0.7133, 0.7119]
        self.lambda_w_Macro_F1 = [0.1862, 0.1936, 0.1799, 0.1727, 0.1795, 0.1830, 0.1835]
        self.lambda_w_Micro_F1 = [0.7184, 0.7220, 0.7148, 0.7119, 0.7157, 0.7172, 0.7177]  # 创建图并命名
        fig = plt.figure(figsize=(18, 4), facecolor='w')
        ax = fig.add_subplot(131)
        lns1 = ax.plot(self.lambda_a, self.lambda_a_Macro_F1, 'D-', linestyle='dashed', markersize=6, c='r', lw=2.5,
                       alpha=0.8, label='Macro_F1')
        ax.tick_params(axis='y', colors='r', direction='in')
        plt.ylim(0.171, 0.197)
        plt.yticks([0.171,(0.171 + 0.197) / 2, 0.197])
        ax2 = ax.twinx()
        lns2 = ax2.plot(self.lambda_a, self.lambda_a_Micro_F1, '*-', linestyle='solid', markersize=10, c='b', lw=2.5,
                        alpha=0.8,
                        label='Micro_F1')
        ax2.tick_params(axis='y', colors='b', direction='in')
        plt.ylim(0.711, 0.723)
        plt.yticks([0.711,  (0.711 + 0.723) / 2, 0.723])
        lns = lns1 + lns2
        labs = [l.get_label() for l in lns]
        ax.legend(lns, labs)
        ax.tick_params(direction='in')
        plt.xticks([1, 2, 3, 4, 5, 6, 7], [0.001, 0.01, 0.1, 0.5, 1, 3, 5])
        ax.set_ylabel('Macro_F1', fontdict=self.font_y1)
        ax2.set_ylabel('Micro_F1', fontdict=self.font_y2)
        ax.set_xlabel(r'$\lambda_a$', self.font_x)
        plt.xlim(np.min(self.lambda_a), np.max(self.lambda_a))
        # plt.title('(a) $\lambda_a$', fontsize=15)

        ax = fig.add_subplot(132)
        lns1 = ax.plot(self.lambda_s, self.lambda_s_Macro_F1, 'D-', linestyle='dashed', markersize=6, c='r', lw=2.5,
                       alpha=0.8, label='Macro_F1')
        ax.tick_params(axis='y', colors='r', direction='in')
        plt.ylim(0.170, 0.196)
        plt.yticks([0.170, (0.170 + 0.196) / 2, 0.196])
        ax2 = ax.twinx()
        lns2 = ax2.plot(self.lambda_s, self.lambda_s_Micro_F1, '*-', linestyle='solid', markersize=10, c='b', lw=2.5,
                        alpha=0.8,
                        label='Micro_F1')
        ax2.tick_params(axis='y', colors='b', direction='in')
        plt.ylim(0.711, 0.725)
        plt.yticks([0.711, (0.711 + 0.725) / 2, 0.725])
        lns = lns1 + lns2
        labs = [l.get_label() for l in lns]
        ax.legend(lns, labs)
        ax.tick_params(direction='in')
        plt.xticks([1, 2, 3, 4, 5, 6, 7], [0.001, 0.01, 0.1, 0.5, 1, 3, 5])
        ax.set_ylabel('Macro_F1', fontdict=self.font_y1)
        ax2.set_ylabel('Micro_F1', fontdict=self.font_y2)
        ax.set_xlabel(r'$\lambda_s$', self.font_x)
        plt.xlim(np.min(self.lambda_s), np.max(self.lambda_s))
        # plt.title('(b) $\lambda_s$', fontsize=15)

        ax = fig.add_subplot(133)
        lns1 = ax.plot(self.lambda_w, self.lambda_w_Macro_F1, 'D-', linestyle='dashed', markersize=6, c='r', lw=2.5,
                       alpha=0.8, label='Macro_F1')
        ax.tick_params(axis='y', colors='r', direction='in')
        plt.ylim(0.170, 0.198)
        plt.yticks([0.170, (0.170 + 0.198) / 2, 0.198])
        ax2 = ax.twinx()
        lns2 = ax2.plot(self.lambda_w, self.lambda_w_Micro_F1, '*-', linestyle='solid', markersize=10, c='b', lw=2.5,
                        alpha=0.8,
                        label='Micro_F1')
        ax2.tick_params(axis='y', colors='b', direction='in')
        plt.ylim(0.711, 0.723)
        plt.yticks([0.711, (0.711 + 0.723) / 2, 0.723])
        plt.xticks([6, 7, 8, 9, 10], [6, 7, 8, 9, 10])
        lns = lns1 + lns2
        labs = [l.get_label() for l in lns]
        ax.legend(lns, labs)
        ax.tick_params(direction='in')
        plt.xticks([1, 2, 3, 4, 5, 6, 7], [0.001, 0.01, 0.1, 0.5, 1, 3, 5])
        ax.set_ylabel('Macro_F1', fontdict=self.font_y1)
        ax2.set_ylabel('Micro_F1', fontdict=self.font_y2)
        ax.set_xlabel(r'$\lambda_w$', self.font_x)
        plt.xlim(np.min(self.lambda_w), np.max(self.lambda_w))
        # plt.title('(c) $\lambda_w$', fontsize=15)

        plt.tight_layout()
        plt.subplots_adjust(left=None, bottom=None, right=None, top=None,
                            wspace=0.4, hspace=None)
        plt.savefig(self.path + 'lambda.png', dpi=300)
        plt.show()



    def all_F1(self):
        self.L = [0, 1, 2, 3, 4, 5]
        self.Macro_F1 = [0.1935, 0.1927, 0.1931, 0.1827, 0.1777, 0.1777]
        self.Micro_F1 = [0.7230, 0.7230, 0.7230, 0.7184, 0.7138, 0.7148]
        fig = plt.figure(figsize=(12, 12), facecolor='w')
        ax = fig.add_subplot(321)
        lns1 = ax.plot(self.L, self.Macro_F1, 'D-', linestyle='dashed', markersize=6, c='r', lw=2.5,
                       alpha=0.8, label='Macro_F1')
        ax.tick_params(axis='y', colors='r', direction='in')
        plt.ylim(0.177, 0.195)
        plt.yticks([0.177, (0.177 + 0.195)/2, 0.195])
        ax2 = ax.twinx()
        lns2 = ax2.plot(self.L, self.Micro_F1, '*-', linestyle='solid', markersize=10, c='b', lw=2.5,
                        alpha=0.8,
                        label='Micro_F1')
        ax2.tick_params(axis='y', colors='b', direction='in')
        plt.ylim(0.712,0.724)
        plt.yticks([0.712, (0.712+0.724)/2,0.724])
        lns = lns1 + lns2
        labs = [l.get_label() for l in lns]
        ax.legend(lns, labs)
        ax.tick_params(direction='in')
        plt.xticks([0, 1, 2, 3, 4, 5], [0, 100, 500, 1000, 1500, 2000])
        ax.set_ylabel('Macro_F1', fontdict=self.font_y1)
        ax2.set_ylabel('Micro_F1', fontdict=self.font_y2)
        ax.set_xlabel(r'$L$', self.font_x)
        plt.xlim(np.min(self.L), np.max(self.L))
        plt.title('(a) Iterations $L$', fontsize=15)

        self.eta_a = [1, 2, 3, 4, 5]
        self.eta_w = [1, 2, 3, 4, 5]
        self.eta_a_Macro_F1 = [0.2018, 0.1967, 0.1924, 0.1865, 0.1750]
        self.eta_a_Micro_F1 = [0.7271, 0.7247, 0.7230, 0.7196, 0.7131]
        self.eta_w_Macro_F1 = [0.1969, 0.1885, 0.1748, 0.1922, 0.1726]
        self.eta_w_Micro_F1 = [0.7249, 0.7201, 0.7121, 0.7230, 0.7119]
        # fig = plt.figure(figsize=(12, 4), facecolor='w')
        ax = fig.add_subplot(322)
        lns1 = ax.plot(self.eta_a, self.eta_a_Macro_F1, 'D-', linestyle='dashed', markersize=6, c='r', lw=2.5,
                       alpha=0.8, label='Macro_F1')
        ax.tick_params(axis='y', colors='r', direction='in')
        plt.ylim(0.174, 0.207)
        plt.yticks([0.174, (0.174 + 0.207) / 2, 0.207])
        ax2 = ax.twinx()
        lns2 = ax2.plot(self.eta_a, self.eta_a_Micro_F1, '*-', linestyle='solid', markersize=10, c='b', lw=2.5,
                        alpha=0.8,
                        label='Micro_F1')
        ax2.tick_params(axis='y', colors='b', direction='in')
        plt.ylim(0.712, 0.730)
        plt.yticks([0.712, (0.712 + 0.730) / 2, 0.730])
        lns = lns1 + lns2
        labs = [l.get_label() for l in lns]
        ax.legend(lns, labs)
        ax.tick_params(direction='in')
        plt.xticks([1, 2, 3, 4, 5], [0.00001, 0.0001, 0.001, 0.01, 0.1])
        ax.set_ylabel('Macro_F1', fontdict=self.font_y1)
        ax2.set_ylabel('Micro_F1', fontdict=self.font_y2)
        ax.set_xlabel(r'$\eta_a$', self.font_x)
        plt.xlim(np.min(self.eta_a), np.max(self.eta_a))
        plt.title('(b) Learning rate $\eta_a$', fontsize=15)

        ax = fig.add_subplot(323)
        lns1 = ax.plot(self.eta_w, self.eta_w_Macro_F1, 'D-', linestyle='dashed', markersize=6, c='r', lw=2.5,
                       alpha=0.8, label='Macro_F1')
        ax.tick_params(axis='y', colors='r', direction='in')
        plt.ylim(0.170, 0.200)
        plt.yticks([0.170, (0.170+0.200)/2, 0.200])
        ax2 = ax.twinx()
        lns2 = ax2.plot(self.eta_w, self.eta_w_Micro_F1, '*-', linestyle='solid', markersize=10, c='b', lw=2.5,
                        alpha=0.8,
                        label='Micro_F1')
        ax2.tick_params(axis='y', colors='b', direction='in')
        plt.ylim(0.710, 0.726)
        plt.yticks([0.710, (0.710 + 0.726) / 2, 0.726])
        lns = lns1 + lns2
        labs = [l.get_label() for l in lns]
        ax.legend(lns, labs)
        plt.xticks([1, 2, 3, 4, 5], [0.00001, 0.0001, 0.001, 0.01, 0.1])
        ax.set_ylabel('Macro_F1', fontdict=self.font_y1)
        ax2.set_ylabel('Micro_F1', fontdict=self.font_y2)
        ax.set_xlabel(r'$\eta_w$', self.font_x)
        plt.xlim(np.min(self.eta_w), np.max(self.eta_w))
        plt.title('(c) Learning rate $\eta_w$', fontsize=8)

        # plt.tight_layout()
        # plt.subplots_adjust(left=None, bottom=None, right=None, top=None,
        #                     wspace=0.4, hspace=None)
        # # plt.savefig(self.path + 'eta.png', dpi=300)
        # plt.show()

        self.lambda_a = [1, 2, 3, 4, 5, 6, 7]
        self.lambda_s = [1, 2, 3, 4, 5, 6, 7]
        self.lambda_w = [1, 2, 3, 4, 5, 6, 7]
        self.lambda_a_Macro_F1 = [0.1726, 0.1724, 0.1835, 0.1877, 0.1936, 0.1746, 0.1753]
        self.lambda_a_Micro_F1 = [0.7119, 0.7119, 0.7169, 0.7201, 0.7220, 0.7121, 0.7133]
        self.lambda_s_Macro_F1 = [0.1923, 0.1867, 0.1887, 0.1949, 0.1772, 0.1757, 0.1727]
        self.lambda_s_Micro_F1 = [0.7220, 0.7196, 0.7196, 0.7240, 0.7143, 0.7133, 0.7119]
        self.lambda_w_Macro_F1 = [0.1782, 0.1858, 0.1799, 0.1727, 0.1795, 0.1739, 0.1736]
        self.lambda_w_Micro_F1 = [0.7143, 0.7182, 0.7148, 0.7119, 0.7157, 0.7126, 0.7126]  # 创建图并命名
        # fig = plt.figure(figsize=(18, 4), facecolor='w')
        ax = fig.add_subplot(324)
        lns1 = ax.plot(self.lambda_a, self.lambda_a_Macro_F1, 'D-', linestyle='dashed', markersize=6, c='r', lw=2.5,
                       alpha=0.8, label='Macro_F1')
        ax.tick_params(axis='y', colors='r', direction='in')
        plt.ylim(0.171, 0.197)
        plt.yticks([0.171,(0.171 + 0.197) / 2, 0.197])
        ax2 = ax.twinx()
        lns2 = ax2.plot(self.lambda_a, self.lambda_a_Micro_F1, '*-', linestyle='solid', markersize=10, c='b', lw=2.5,
                        alpha=0.8,
                        label='Micro_F1')
        ax2.tick_params(axis='y', colors='b', direction='in')
        plt.ylim(0.711, 0.723)
        plt.yticks([0.711,  (0.711 + 0.723) / 2, 0.723])
        lns = lns1 + lns2
        labs = [l.get_label() for l in lns]
        ax.legend(lns, labs)
        ax.tick_params(direction='in')
        plt.xticks([1, 2, 3, 4, 5, 6, 7], [0.001, 0.01, 0.1, 0.5, 1, 3, 5])
        ax.set_ylabel('Macro_F1', fontdict=self.font_y1)
        ax2.set_ylabel('Micro_F1', fontdict=self.font_y2)
        ax.set_xlabel(r'$\lambda_a$', self.font_x)
        plt.xlim(np.min(self.lambda_a), np.max(self.lambda_a))
        plt.title('(d) Regularization parameter $\lambda_a$', fontsize=15)

        ax = fig.add_subplot(325)
        lns1 = ax.plot(self.lambda_s, self.lambda_s_Macro_F1, 'D-', linestyle='dashed', markersize=6, c='r', lw=2.5,
                       alpha=0.8, label='Macro_F1')
        ax.tick_params(axis='y', colors='r', direction='in')
        plt.ylim(0.170, 0.196)
        plt.yticks([0.170, (0.170 + 0.196) / 2, 0.196])
        ax2 = ax.twinx()
        lns2 = ax2.plot(self.lambda_s, self.lambda_s_Micro_F1, '*-', linestyle='solid', markersize=10, c='b', lw=2.5,
                        alpha=0.8,
                        label='Micro_F1')
        ax2.tick_params(axis='y', colors='b', direction='in')
        plt.ylim(0.711, 0.725)
        plt.yticks([0.711, (0.711 + 0.725) / 2, 0.725])
        lns = lns1 + lns2
        labs = [l.get_label() for l in lns]
        ax.legend(lns, labs)
        ax.tick_params(direction='in')
        plt.xticks([1, 2, 3, 4, 5, 6, 7], [0.001, 0.01, 0.1, 0.5, 1, 3, 5])
        ax.set_ylabel('Macro_F1', fontdict=self.font_y1)
        ax2.set_ylabel('Micro_F1', fontdict=self.font_y2)
        ax.set_xlabel(r'$\lambda_s$', self.font_x)
        plt.xlim(np.min(self.lambda_s), np.max(self.lambda_s))
        plt.title('(e) Regularization parameter $\lambda_s$', fontsize=15)

        ax = fig.add_subplot(326)
        lns1 = ax.plot(self.lambda_w, self.lambda_w_Macro_F1, 'D-', linestyle='dashed', markersize=6, c='r', lw=2.5,
                       alpha=0.8, label='Macro_F1')
        ax.tick_params(axis='y', colors='r', direction='in')
        plt.ylim(0.170, 0.198)
        plt.yticks([0.170, (0.170 + 0.198) / 2, 0.198])
        ax2 = ax.twinx()
        lns2 = ax2.plot(self.lambda_w, self.lambda_w_Micro_F1, '*-', linestyle='solid', markersize=10, c='b', lw=2.5,
                        alpha=0.8,
                        label='Micro_F1')
        ax2.tick_params(axis='y', colors='b', direction='in')
        plt.ylim(0.711, 0.723)
        plt.yticks([0.711, (0.711 + 0.723) / 2, 0.723])
        plt.xticks([6, 7, 8, 9, 10], [6, 7, 8, 9, 10])
        lns = lns1 + lns2
        labs = [l.get_label() for l in lns]
        ax.legend(lns, labs)
        ax.tick_params(direction='in')
        plt.xticks([1, 2, 3, 4, 5, 6, 7], [0.001, 0.01, 0.1, 0.5, 1, 3, 5])
        ax.set_ylabel('Macro_F1', fontdict=self.font_y1)
        ax2.set_ylabel('Micro_F1', fontdict=self.font_y2)
        ax.set_xlabel(r'$\lambda_w$', self.font_x)
        plt.xlim(np.min(self.lambda_w), np.max(self.lambda_w))
        plt.title('(f) Regularization parameter  $\lambda_w$', fontsize=15)

        plt.tight_layout()
        plt.subplots_adjust(left=None, bottom=None, right=None, top=None,
                            wspace=0.5, hspace=0.5)
        plt.savefig(self.path + 'all.jpg', dpi=600)
        plt.show()


    def P_F1(self):
        self.T_edx = [0, 1, 2]
        self.T_xtx = [6, 7, 8, 9, 10]
        self.Person_Course_Macro_F1 = [0, 0.3573, 0.4035]
        self.Person_Course_Micro_F1 = [0, 0.5353, 0.5993]
        self.xuetangX_Macro_F1 = [0.2580, 0.2680, 0.2738, 0.3038, 0.3209]
        self.xuetangX_Micro_F1 = [0.8627, 0.9288, 0.9475, 0.9487, 0.9499]  # 创建图并命名
        fig = plt.figure(figsize=(9, 3), facecolor='w')
        ax = fig.add_subplot(121)
        lns1 = ax.plot(self.T_edx, self.Person_Course_Macro_F1, 'D-', linestyle='dashed', markersize=6, c='r', lw=2.5,
                       alpha=0.8, label='Macro_F1')
        ax.tick_params(axis='y', colors='r', direction='in')
        plt.ylim(0, 0.440)
        plt.yticks([0, (0 + 0.440) / 2, 0.440])
        ax2 = ax.twinx()
        lns2 = ax2.plot(self.T_edx, self.Person_Course_Micro_F1, '*-', linestyle='solid', markersize=10, c='b', lw=2.5,
                        alpha=0.8,
                        label='Micro_F1')
        ax2.tick_params(axis='y', colors='b', direction='in')
        plt.ylim(0, 0.640)
        plt.yticks([0, (0 + 0.640) / 2, 0.640])
        lns = lns1 + lns2
        labs = [l.get_label() for l in lns]
        ax.legend(lns, labs)
        ax.tick_params(direction='in')
        plt.xticks([0, 1, 2])
        ax.set_ylabel('Macro_F1', fontdict=self.font_y1)
        ax2.set_ylabel('Micro_F1', fontdict=self.font_y2)
        ax.set_xlabel(r'$P$', self.font_x)
        plt.xlim(np.min(self.T_edx), np.max(self.T_edx))
        plt.title('(a) Person_Course', fontsize=15)

        ax = fig.add_subplot(122)
        lns1 = ax.plot(self.T_xtx, self.xuetangX_Macro_F1, 'D-', linestyle='dashed', markersize=6, c='r', lw=2.5,
                       alpha=0.8, label='Macro_F1')
        ax.tick_params(axis='y', colors='r', direction='in')
        plt.ylim(0.250, 0.330)
        plt.yticks([0.25, (0.250 + 0.330) / 2, 0.330])
        ax2 = ax.twinx()
        lns2 = ax2.plot(self.T_xtx, self.xuetangX_Micro_F1, '*-', linestyle='solid', markersize=10, c='b', lw=2.5,
                        alpha=0.8,
                        label='Micro_F1')
        ax2.tick_params(axis='y', colors='b', direction='in')
        plt.ylim(0.860, 0.960)
        plt.yticks([0.860, (0.860 + 0.960) / 2, 0.960])
        plt.xticks([6, 7, 8, 9, 10], [6, 7, 8, 9, 10])
        lns = lns1 + lns2
        labs = [l.get_label() for l in lns]
        ax.legend(lns, labs,loc='NorthEast')
        ax.tick_params(direction='in')
        ax.set_ylabel('Macro_F1', fontdict=self.font_y1)
        ax2.set_ylabel('Micro_F1', fontdict=self.font_y2)
        ax.set_xlabel(r'$P$', self.font_x)
        plt.xlim(np.min(self.T_xtx), np.max(self.T_xtx))
        plt.title('(b) xuetangX', fontsize=15)

        plt.tight_layout()
        plt.subplots_adjust(left=None, bottom=None, right=None, top=None,
                            wspace=0.6, hspace=None)
        plt.savefig(self.path + 'p.jpg', dpi=600)
        plt.show()


if __name__ == '__main__':
    start = time.clock()
    end = time.clock()
    p = plt_parameter_analysis()
    # p.iterate_F1()
    # p.eta_F1()
    # p.lambda_F1()
    p.all_F1()
    # p.P_F1()

    print("time_run:", end - start)