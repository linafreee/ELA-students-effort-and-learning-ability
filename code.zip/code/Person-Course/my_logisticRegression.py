import pandas as pd
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler, PolynomialFeatures
from sklearn.pipeline import Pipeline
import evaluate

class logisticRegression():
    def __init__(self,name1,name2):
        self.path = "F:/Pycharm/paper/1 Learning Ability/data/MIT/model/"
        self.name1 = name1
        self.name2 = name2
        self.train_data = pd.read_csv(self.path + 'my_'+ self.name1 + '_for_classify.csv', header=None)
        self.train_x, self.train_y = np.split(self.train_data.values, (2,), axis=1)
        self.test_data = pd.read_csv(self.path + 'my_'+ self.name2 + '_for_classify.csv', header=None)
        self.test_x, self.test_y = np.split(self.test_data.values, (2,), axis=1)
        self.train_y = self.train_y.flatten()
        self.test_y = self.test_y.flatten()

    def LR(self,t):
        # fit
        self.t = t
        self.lr = Pipeline([('sc', StandardScaler()),
                            ('poly', PolynomialFeatures(degree=6)),
                            ('clf', LogisticRegression(C=0.1))])  # ELA-10；N_ELA-0.1
        self.lr.fit(self.train_x, self.train_y)
        self.train_y_hat = self.lr.predict(self.train_x)
        e = evaluate.evaluate()
        self.e_t_0 = e.metric(self.train_y, self.train_y_hat, self.t)
        self.test_y_hat = self.lr.predict(self.test_x)
        self.e_t_1 = e.metric(self.test_y, self.test_y_hat,self.t)
        return self.e_t_0,self.e_t_1

if __name__ == '__main__':
    pass